#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    long long n, m, k;
    cin >> n >> m >> k;

    if (n == 1 && m == 1) {
        cout << 0 << endl;
        return 0;
    }

    long long x = min(n - 1, m - 1) / k;
    long long rem_r = (n - 1) % k;
    long long rem_c = (m - 1) % k;

    if (rem_r == 0 && rem_c == 0) {
        cout << x << endl;
    } else if (rem_r > 0 && rem_c > 0) {
        cout << x + 2 << endl;
    } else {
        cout << x + 1 << endl;
    }

    return 0;
}