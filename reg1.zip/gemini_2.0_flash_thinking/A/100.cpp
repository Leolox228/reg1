#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    long long n, m, k;
    cin >> n >> m >> k;

    if (n == 1 && m == 1) {
        cout << 0 << endl;
        return 0;
    }

    long long n_diff = n - 1;
    long long m_diff = m - 1;

    long long min_diff = min(n_diff, m_diff);
    long long max_diff = max(n_diff, m_diff);

    long long diagonal_moves = (min_diff + k - 1) / k;
    long long remaining_moves = (max_diff - min_diff + k - 1) / k;

    cout << diagonal_moves + remaining_moves << endl;

    return 0;
}