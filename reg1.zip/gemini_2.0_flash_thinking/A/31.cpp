#include <iostream>
#include <vector>
#include <queue>
#include <map>

using namespace std;

int main() {
    long long n, m, k;
    cin >> n >> m >> k;

    if (n == 1 && m == 1) {
        cout << 0 << endl;
        return 0;
    }

    queue<pair<long long, long long>> q;
    q.push({1, 1});
    map<pair<long long, long long>, int> distance;
    distance[{1, 1}] = 0;

    while (!q.empty()) {
        pair<long long, long long> current_cell = q.front();
        q.pop();
        long long r = current_cell.first;
        long long c = current_cell.second;

        if (r == n && c == m) {
            cout << distance[{r, c}] << endl;
            return 0;
        }

        // Right moves
        for (int j = 1; j <= k; ++j) {
            long long next_c = c + j;
            if (next_c <= m) {
                if (distance.find({r, next_c}) == distance.end()) {
                    distance[{r, next_c}] = distance[{r, c}] + 1;
                    q.push({r, next_c});
                }
            } else {
                break;
            }
        }

        // Up moves
        for (int i = 1; i <= k; ++i) {
            long long next_r = r + i;
            if (next_r <= n) {
                if (distance.find({next_r, c}) == distance.end()) {
                    distance[{next_r, c}] = distance[{r, c}] + 1;
                    q.push({next_r, c});
                }
            } else {
                break;
            }
        }

        // Diagonal moves
        for (int d = 1; d <= k; ++d) {
            long long next_r = r + d;
            long long next_c = c + d;
            if (next_r <= n && next_c <= m) {
                if (distance.find({next_r, next_c}) == distance.end()) {
                    distance[{next_r, next_c}] = distance[{r, c}] + 1;
                    q.push({next_r, next_c});
                }
            } else {
                break;
            }
        }
    }

    return 0;
}