#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    long long n, m, k;
    cin >> n >> m >> k;

    if (n == 1 && m == 1) {
        cout << 0 << endl;
        return 0;
    }

    long long current_r = 1;
    long long current_c = 1;
    int moves = 0;

    while (current_r < n || current_c < m) {
        long long diag_step = min({k, n - current_r, m - current_c});
        if (diag_step > 0) {
            current_r += diag_step;
            current_c += diag_step;
        } else {
            long long right_step = min(k, m - current_c);
            if (right_step > 0) {
                current_c += right_step;
            } else {
                long long up_step = min(k, n - current_r);
                current_r += up_step;
            }
        }
        moves++;
    }

    cout << moves << endl;

    return 0;
}