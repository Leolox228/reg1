#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

bool is_prime_product(const string& s) {
    int product = 1;
    for (char c : s) {
        product *= (c - '0');
    }
    if (product == 2 || product == 3 || product == 5 || product == 7) {
        return true;
    }
    return false;
}

string subtract_one(string s) {
    if (s == "1") {
        return "0";
    }
    int n = s.length();
    for (int i = n - 1; i >= 0; --i) {
        if (s[i] > '0') {
            s[i]--;
            return s;
        } else {
            s[i] = '9';
        }
    }
    return s; // Should not reach here for input s > "0"
}

long long count_simple_minded_up_to(string r_str) {
    long long count = 0;
    int r_len = r_str.length();
    if (r_str == "0") return 0;
    for (int len = 1; len < r_len; ++len) {
        count += (long long)len * 4;
    }
    vector<int> primes = {2, 3, 5, 7};
    for (int i = 0; i < r_len; ++i) {
        for (int p : primes) {
            string current_num_str = "";
            for (int j = 0; j < r_len; ++j) {
                if (i == j) {
                    current_num_str += to_string(p);
                } else {
                    current_num_str += '1';
                }
            }
            if (current_num_str.length() < r_str.length() || (current_num_str.length() == r_str.length() && current_num_str <= r_str)) {
                count++;
            }
        }
    }
    return count;
}

int main() {
    string l_str, r_str;
    cin >> l_str >> r_str;

    string l_minus_one_str = subtract_one(l_str);
    long long count_r = count_simple_minded_up_to(r_str);
    long long count_l_minus_one = 0;
    if (l_minus_one_str != "0") {
        count_l_minus_one = count_simple_minded_up_to(l_minus_one_str);
    }

    cout << count_r - count_l_minus_one << endl;

    return 0;
}