#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>

using namespace std;

long long calculate_capacity(const vector<int>& segment_heights) {
    int n = segment_heights.size();
    if (n == 0) {
        return 0;
    }
    vector<int> max_left(n), max_right(n);
    max_left[0] = segment_heights[0];
    for (int i = 1; i < n; ++i) {
        max_left[i] = max(max_left[i - 1], segment_heights[i]);
    }
    max_right[n - 1] = segment_heights[n - 1];
    for (int i = n - 2; i >= 0; --i) {
        max_right[i] = max(max_right[i + 1], segment_heights[i]);
    }

    long long total_capacity = 0;
    for (int i = 0; i < n; ++i) {
        int depth = min(max_left[i], max_right[i]) - segment_heights[i];
        total_capacity += max(0, depth);
    }
    return total_capacity;
}

int main() {
    int n;
    cin >> n;
    vector<int> h(n);
    for (int i = 0; i < n; ++i) {
        cin >> h[i];
    }
    vector<int> merge_instructions(n - 1);
    for (int i = 0; i < n - 1; ++i) {
        cin >> merge_instructions[i];
    }

    vector<vector<int>> segments;
    for (int height : h) {
        segments.push_back({height});
    }

    vector<long long> capacities;
    for (int instruction : merge_instructions) {
        int merge_index = instruction - 1;
        vector<int> segment1 = segments[merge_index];
        vector<int> segment2 = segments[merge_index + 1];
        vector<int> merged_segment = segment1;
        merged_segment.insert(merged_segment.end(), segment2.begin(), segment2.end());
        segments.erase(segments.begin() + merge_index, segments.begin() + merge_index + 2);
        segments.insert(segments.begin() + merge_index, merged_segment);
        capacities.push_back(calculate_capacity(merged_segment));
    }

    for (int i = 0; i < capacities.size(); ++i) {
        cout << capacities[i] << (i == capacities.size() - 1 ? "" : "\n");
    }
    cout << endl;

    return 0;
}