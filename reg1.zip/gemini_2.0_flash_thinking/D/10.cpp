#include <iostream>
#include <vector>
#include <numeric>
#include <functional> // Include the functional header for std::function

using namespace std;

int main() {
    int n, k;
    cin >> n >> k;
    vector<int> b(n);
    for (int i = 0; i < n; ++i) {
        cin >> b[i];
    }

    vector<vector<int>> table(k, vector<int>(n, 0));
    long long count = 0;
    long long modulo = 1e9 + 7;

    std::function<void(int, int)> solve = [&](int row, int col) { // Use std::function
        if (col == n) {
            bool correct = true;
            for (int p = 1; p <= n; ++p) {
                int scan_value = 0;
                for (int j = max(1, p - k + 1); j <= p; ++j) {
                    for (int i = 1; i <= k - (p - j); ++i) {
                        scan_value += table[i - 1][j - 1];
                    }
                }
                if (scan_value != b[p - 1]) {
                    correct = false;
                    break;
                }
            }
            if (correct) {
                count++;
            }
            return;
        }

        if (row == k) {
            solve(0, col + 1);
            return;
        }

        table[row][col] = 0;
        solve(row + 1, col);
        table[row][col] = 1;
        solve(row + 1, col);
        table[row][col] = 0; // Backtrack
    };

    solve(0, 0);

    cout << count % modulo << endl;

    return 0;
}