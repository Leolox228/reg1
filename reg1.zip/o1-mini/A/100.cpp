#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    ll n, m, k;
    cin >> n >> m >> k;
    ll dx = n -1;
    ll dy = m -1;
    ll min_d = min(dx, dy);
    ll t_diagonal = (min_d + k -1) / k;
    ll dx_remaining, dy_remaining;
    if(dx >= dy){
        dx_remaining = dx - dy;
        dy_remaining = 0;
    }
    else{
        dx_remaining = 0;
        dy_remaining = dy - dx;
    }
    ll moves = t_diagonal;
    if(dx_remaining >0){
        moves += (dx_remaining + k -1)/k;
    }
    if(dy_remaining >0){
        moves += (dy_remaining + k -1)/k;
    }
    cout << moves;
}
