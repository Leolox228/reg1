#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Функция для округления вверх при делении
ll ceil_div(ll a, ll b){
    if(b == 0) return 0; // предотвращение деления на ноль
    return (a + b - 1) / b;
}

// Функция для проверки, возможно ли достичь (dx, dy) за t ходов
bool is_possible(ll t, ll dx, ll dy, ll k){
    // Максимальное количество диагональных ходов
    ll d = min(t, min(dx / k, dy / k));
    
    // Остатки после диагональных ходов
    ll rem_x = dx - d * k;
    ll rem_y = dy - d * k;
    
    // Количество необходимых дополнительных ходов вправо и вверх
    ll r = (rem_x > 0) ? ceil_div(rem_x, k) : 0;
    ll u = (rem_y > 0) ? ceil_div(rem_y, k) : 0;
    
    return (d + r + u) <= t;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    ll n, m, k;
    cin >> n >> m >> k;
    ll dx = n - 1;
    ll dy = m - 1;
    
    // Если начальная и конечная позиции совпадают
    if(dx == 0 && dy == 0){
        cout << 0;
        return 0;
    }
    
    // Бинарный поиск по количеству ходов
    ll left = 1;
    ll right = 2e9; // Максимально возможное количество ходов
    ll answer = right;
    
    while(left <= right){
        ll mid = left + (right - left) / 2;
        if(is_possible(mid, dx, dy, k)){
            answer = mid;
            right = mid -1;
        }
        else{
            left = mid +1;
        }
    }
    
    cout << answer;
}
