#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

// Функция для округления вверх
ll ceil_div(ll a, ll b){
    if(b ==0) return 0; // предотвращение деления на ноль
    return (a + b -1) /b;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    ll n, m, k;
    cin >> n >> m >> k;
    ll a = (n >1)? ceil_div(n-1, k) : 0;
    ll b = (m >1)? ceil_div(m-1, k) : 0;
    ll res = max(a, b);
    cout << res;
}
