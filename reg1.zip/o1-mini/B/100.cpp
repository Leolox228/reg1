#include <bits/stdc++.h>
using namespace std;

// Function to subtract one from a large number represented as a string
string subtract_one(string s) {
    int n = s.length();
    string res = s;
    int p = n - 1;
    while (p >= 0 && res[p] == '0') {
        res[p] = '9';
        p--;
    }
    if (p >= 0) {
        res[p]--;
    }
    // Remove leading zero if present
    if (res.length() > 1 && res[0] == '0') {
        res.erase(0, 1);
    }
    return res;
}

// Digit DP function to count prostovaty numbers <= x
long long digit_dp(const string &x) {
    int m = x.length();
    // Initialize current state: current[count][tight]
    // count: 0 or 1 (number of prime digits placed)
    // tight: 0 or 1 (whether the number is tight to x)
    vector<vector<long long>> current(2, vector<long long>(2, 0));
    current[0][1] = 1; // Starting with no prime digits and tight

    // Allowed digits: 1, 2, 3, 5, 7
    vector<int> allowed_digits = {1, 2, 3, 5, 7};

    for (int pos = 0; pos < m; pos++) {
        // Initialize next state
        vector<vector<long long>> next_(2, vector<long long>(2, 0));

        for (int count = 0; count <= 1; count++) {
            for (int tight = 0; tight <= 1; tight++) {
                if (current[count][tight] == 0)
                    continue;

                int max_digit = tight ? (x[pos] - '0') : 9;

                for (auto d : allowed_digits) {
                    // If tight, digit cannot exceed max_digit
                    if (tight && d > max_digit)
                        continue;

                    // If first digit is zero, skip
                    if (pos == 0 && d == 0)
                        continue;

                    int new_count = count;
                    // Update count based on the digit placed
                    if (d == 1) {
                        // No change in count
                    } else if (d == 2 || d == 3 || d == 5 || d == 7) {
                        if (count == 0)
                            new_count = 1;
                        else
                            continue; // Already placed a prime digit
                    } else {
                        continue; // Invalid digit
                    }

                    // Update tight flag
                    int new_tight = tight && (d == (x[pos] - '0'));

                    next_[new_count][new_tight] += current[count][tight];
            }
        }
    }

        // Update current state
        current = next_;
    }

    // Total prostovaty numbers <= x with exactly one prime digit
    return current[1][0] + current[1][1];
}

// Function to count all prostovaty numbers up to x
long long count_total(const string &x) {
    int m = x.length();
    if (m == 0)
        return 0;
    // Count prostovaty numbers with length less than m
    // For each length from 1 to m-1, there are 4 * length prostovaty numbers
    long long total = 0;
    if (m >= 2) {
        total += 4LL * (m - 1) * m / 2;
    } else if (m == 1) {
        // For m=1, no numbers with length less than 1
        total += 0;
    }
    // Count prostovaty numbers with length exactly m and <= x
    total += digit_dp(x);
    return total;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    string l, r;
    cin >> l >> r;

    // Count prostovaty numbers up to r
    long long count_r = count_total(r);

    // Compute l-1
    string l_minus_one;
    if(l == "0"){
        l_minus_one = "0";
    }
    else{
        l_minus_one = subtract_one(l);
    }

    // Count prostovaty numbers up to l-1
    long long count_l = 0;
    if(l_minus_one != "0"){
        count_l = count_total(l_minus_one);
    }

    // The answer is count_r - count_l
    cout << (count_r - count_l);
}
