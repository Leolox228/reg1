#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

struct Segment {
    int start; // Начальный индекс блока
    int end;   // Конечный индекс блока
};

// Функция для вычисления емкости сегмента
ll compute_capacity(const vector<ll> &h, int l, int r) {
    // Вычисляем левые максимумы
    vector<ll> left_max(r - l + 1, 0);
    left_max[0] = h[l];
    for(int i = 1; i < r - l + 1; ++i) {
        left_max[i] = max(left_max[i-1], h[l + i]);
    }
    // Вычисляем правые максимумы
    vector<ll> right_max(r - l + 1, 0);
    right_max[r - l] = h[r];
    for(int i = r - l -1; i >=0; --i) {
        right_max[i] = max(right_max[i+1], h[l + i]);
    }
    // Вычисляем емкость
    ll capacity = 0;
    for(int i = 0; i < r - l +1; ++i){
        ll water = min(left_max[i], right_max[i]) - h[l + i];
        if(water > 0) capacity += water;
    }
    return capacity;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n;
    cin >> n;
    vector<ll> h(n);
    for(auto &x: h) cin >> x;
    vector<int> instructions(n-1);
    for(auto &x: instructions) cin >> x;
    
    // Инициализируем список сегментов
    vector<Segment> segments;
    for(int i=0;i<n;i++) {
        segments.push_back(Segment{ i, i });
    }
    
    // Обработка инструкций
    for(auto kj: instructions){
        // Индексация сегментов начинается с 1, приводим к 0
        int idx = kj -1;
        if(idx <0 || idx >= (int)segments.size()-1){
            // Некорректный индекс, пропускаем
            cout << "0 ";
            continue;
        }
        // Объединяем сегменты idx и idx+1
        int new_start = segments[idx].start;
        int new_end = segments[idx+1].end;
        // Вычисляем емкость нового сегмента
        ll capacity = compute_capacity(h, new_start, new_end);
        // Заменяем сегменты idx и idx+1 на новый сегмент
        segments.erase(segments.begin() + idx, segments.begin() + idx + 2);
        segments.insert(segments.begin() + idx, Segment{ new_start, new_end });
        // Выводим емкость
        cout << capacity << " ";
    }
    return 0;
}
