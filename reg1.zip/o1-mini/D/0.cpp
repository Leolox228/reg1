#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MOD = 1'000'000'007;

// Функция для кодирования состояния в целое число
int encode_state(vector<int> &state, int k_minus_1_bits) {
    int code = 0;
    for(auto &c : state){
        code = (code << k_minus_1_bits) | c;
    }
    return code;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n, k;
    cin >> n >> k;
    vector<int> b(n);
    for(auto &x : b) cin >> x;
    
    // Максимальное значение для каждого c_i
    // Поскольку k <=7, и b_p <=49, 6 bits достаточно
    int bits_per_ci = 6;
    int state_bits = (k-1)*bits_per_ci;
    int max_state = 1 << state_bits;
    
    // Используем unordered_map для хранения текущего и предыдущего состояний
    // Но для эффективности можно использовать два вектора
    unordered_map<long long, ll> dp_prev, dp_cur;
    // Начальное состояние: все c_i =0
    dp_prev[0] =1;
    
    for(int p=1; p<=n; p++){
        dp_cur.clear();
        if(p >k){
            // Получаем b_p' = b[p -k]
            int bp = b[p -k];
            for(auto &[state, cnt] : dp_prev){
                // Распакуем состояние
                vector<int> c(k-1, 0);
                long long tmp = state;
                for(int i=k-2; i>=0; i--){
                    c[i] = tmp & ((1<<bits_per_ci)-1);
                    tmp >>= bits_per_ci;
                }
                // Вычисляем x1..xk
                vector<int> x(k, 0);
                bool valid = true;
                x[0] = c[k-2];
                for(int i=1; i<k-1; i++) {
                    x[i] = c[k-3-i+1] - c[k-2-i+1];
                    if(x[i] <0 || x[i] >1){
                        valid = false;
                        break;
                    }
                }
                if(!valid){
                    continue;
                }
                // xk
                x[k-1] = bp;
                for(int i=0; i<k-1; i++) x[k-1] -= c[i];
                if(x[k-1] <0 || x[k-1] >1){
                    continue;
                }
                // Проверяем условия для p +i >n
                bool ok = true;
                for(int i=1; i<k; i++){
                    if(p +i >n){
                        int m_i = k -i;
                        // Сумма первых m_i элементов должна быть 0
                        int sum =0;
                        for(int r=0; r<m_i; r++) sum +=x[r];
                        if(sum !=0){
                            ok = false;
                            break;
                        }
                    }
                }
                if(!ok){
                    continue;
                }
                // Вычисляем новые c'_i
                vector<int> new_c(k-1, 0);
                for(int i=1; i<k; i++){
                    if(p +i >n){
                        // Неважно, так как уже проверено
                        new_c[i-1] =0;
                    }
                    else{
                        int m_i = k -i;
                        int sum =0;
                        for(int r=0; r<m_i; r++) sum +=x[r];
                        new_c[i-1] = b[p +i -1] - sum;
                        if(new_c[i-1] <0 || new_c[i-1] > b[p +i -1]){
                            ok = false;
                            break;
                        }
                    }
                }
                if(!ok){
                    continue;
                }
                // Кодируем новое состояние
                int new_state =0;
                for(auto &val : new_c){
                    new_state = (new_state << bits_per_ci) | val;
                }
                dp_cur[new_state] = (dp_cur[new_state] + cnt) % MOD;
            }
        }
        else{
            // p <=k
            for(auto &[state, cnt] : dp_prev){
                // Распакуем состояние
                vector<int> c(k-1, 0);
                long long tmp = state;
                for(int i=k-2; i>=0; i--){
                    c[i] = tmp & ((1<<bits_per_ci)-1);
                    tmp >>= bits_per_ci;
                }
                // Вычисляем x1..x6
                vector<int> x(k, 0);
                bool valid = true;
                x[0] = c[k-2];
                for(int i=1; i<k-1; i++) {
                    x[i] = c[k-3-i+1] - c[k-2-i+1];
                    if(x[i] <0 || x[i] >1){
                        valid = false;
                        break;
                    }
                }
                if(!valid){
                    continue;
                }
                // x7 может быть 0 или1
                for(int x7=0; x7<=1; x7++){
                    vector<int> assign =x;
                    assign[k-1] =x7;
                    // Проверяем условия для p +i >n
                    bool ok = true;
                    for(int i=1; i<k; i++){
                        if(p +i >n){
                            int m_i = k -i;
                            // Сумма первых m_i элементов должна быть 0
                            int sum =0;
                            for(int r=0; r<m_i; r++) sum +=assign[r];
                            if(sum !=0){
                                ok = false;
                                break;
                            }
                        }
                    }
                    if(!ok){
                        continue;
                    }
                    // Вычисляем новые c'_i
                    vector<int> new_c(k-1, 0);
                    for(int i=1; i<k; i++){
                        if(p +i >n){
                            new_c[i-1] =0;
                        }
                        else{
                            int m_i = k -i;
                            int sum =0;
                            for(int r=0; r<m_i; r++) sum +=assign[r];
                            new_c[i-1] = b[p +i -1] - sum;
                            if(new_c[i-1] <0 || new_c[i-1] > b[p +i -1]){
                                ok = false;
                                break;
                            }
                        }
                    }
                    if(!ok){
                        continue;
                    }
                    // Кодируем новое состояние
                    int new_state =0;
                    for(auto &val : new_c){
                        new_state = (new_state << bits_per_ci) | val;
                    }
                    dp_cur[new_state] = (dp_cur[new_state] + cnt) % MOD;
                }
            }
        }
        // Переходим к следующему столбцу
        dp_prev = move(dp_cur);
    }
    
    // Ответ - количество способов с состоянием 0
    if(dp_prev.find(0) != dp_prev.end()){
        cout << dp_prev[0];
    }
    else{
        cout << 0;
    }
}
