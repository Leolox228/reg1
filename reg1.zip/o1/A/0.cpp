#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m, k;
    cin >> n >> m >> k;
    
    // Если уже в целевой клетке (1,1) == (n,m), то ответ 0
    if (n == 1 && m == 1) {
        cout << 0 << "\n";
        return 0;
    }

    // dx и dy — сколько надо пройти клеток вдоль x и y
    long long dx = n - 1;
    long long dy = m - 1;

    // D — максимально возможное число "полных" диагоналей по k клеток
    long long D = min(dx, dy) / k;  // целочисленное деление

    // Остатки после D полных диагоналей
    long long dxr = dx - D*k;
    long long dyr = dy - D*k;

    // Подсчёт оставшихся ходов R
    int R = 0;
    if (dxr == 0 && dyr == 0) {
        R = 0;
    } else if (dxr == 0 || dyr == 0 || (dxr == dyr)) {
        // если остатки равны и >0, либо один равен 0, другой >0
        R = 1;
    } else {
        R = 2;
    }

    long long answer = D + R;
    cout << answer << "\n";

    return 0;
}
