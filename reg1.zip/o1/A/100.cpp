#include <bits/stdc++.h>
using namespace std;

// Функция для целочисленного "потолка" деления a/k
// (чтобы не тянуть за собой double)
long long ceil_div(long long a, long long k) {
    return (a + k - 1) / k; 
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    long long n, m, k;
    cin >> n >> m >> k;
    
    // Если уже в (1,1) == (n,m), ответ 0
    if (n == 1 && m == 1) {
        cout << 0 << "\n";
        return 0;
    }
    
    // Требуется пройти (dx, dy) клеток
    long long dx = n - 1;
    long long dy = m - 1;
    
    // 1) Сколько "полных" диагоналей по k клеток можно сделать
    long long d = min(dx, dy) / k; // целочисл. деление
    long long ans = d;
    
    // 2) Вычитаем из dx, dy эти d*k
    dx -= d * k;
    dy -= d * k;
    
    // 3) Если и dx>0, и dy>0 — делаем еще одну "частичную" диагональ
    //    длиной c = min(dx, dy). Это выгодно, т.к. 1 ход уменьшит и dx, и dy.
    if (dx > 0 && dy > 0) {
        ans++; 
        long long c = min(dx, dy);
        dx -= c;
        dy -= c;
    }
    
    // 4) Теперь хотя бы одна из координат 0, вторую добираем 
    //    горизонтальными/вертикальными прыжками.
    ans += ceil_div(dx, k);
    ans += ceil_div(dy, k);
    
    cout << ans << "\n";
    return 0;
}
