#include <bits/stdc++.h>
using namespace std;

/*
  Функция subtractOne(strNum):
  - Вычитает 1 из большого десятичного числа, записанного в strNum (без ведущих нулей).
  - Предполагаем, что strNum > "0".
  - Возвращает результат также в виде строки без ведущих нулей.
*/
string subtractOne(const string &strNum) {
    // Копируем в буфер, чтобы модифицировать
    // Могли бы делать прямо в месте, но для наглядности - отдельная функция
    string res = strNum;
    int i = (int)res.size() - 1;
    // "Одну" вычитаем, двигаясь справа налево
    while (i >= 0) {
        if (res[i] == '0') {
            res[i] = '9';
            i--;
        } else {
            // Уменьшаем текущую цифру на 1 и завершаем
            res[i] = char(res[i] - 1);
            break;
        }
    }
    // Удаляем лидующий '0', если вдруг получился
    // (например, если было "1000", станет "0999", убираем ведущий '0')
    if (res[0] == '0' && res.size() > 1) {
        // найти первую не-0?
        int pos = 0;
        while (pos < (int)res.size() && res[pos] == '0') {
            pos++;
        }
        // если все обнулились, значит стало "0"
        if (pos == (int)res.size()) {
            return "0";
        }
        res.erase(0, pos);
    }
    return res;
}

/*
  Считаем сумму 4 + 8 + 12 + ... + 4*(n-1) = 4*(1+2+...+(n-1)) = 2*(n-1)*n.
  Для n=0 или 1 — будет 0.
*/
long long sumForLengths(long long n) {
    if (n <= 0) return 0;
    // сумма 4*(1+2+...+n) = 4 * n*(n+1)/2 = 2*n*(n+1)
    // Но нам нужно до (n-1), поэтому:
    // sum_{L=1 to n-1} (4L) = 4 * (n-1)*n/2 = 2*(n-1)*n
    // если n=1, то (n-1)=0 => получится 0
    return 2LL*(n-1)*n;
}

/*
  Подсчитываем количество "простоватых" чисел длины ровно n,
  которые лексикографически (численно) не превышают строку X.
  Возвращает число в диапазоне [0..4*n], достаточно long long.
  
  Реализуем digit DP: dp[pos][used][less], где
    pos  - идём по цифрам с 0 до n (n - длина X),
    used - 0/1/2: сколько простых цифр (2,3,5,7) уже поставлено (2 => уже invalid),
    less - 0/1: флаг, указывает, совпадает ли пока префикс с X (0) или уже меньше (1).
*/
long long countLengthNUpTo(const string &X) {
    int n = (int)X.size();
    // преобразуем X в массив цифр
    vector<int> digits(n);
    for(int i = 0; i < n; i++){
        digits[i] = X[i] - '0';
    }

    // dp[pos][used][less] - количество способов
    // используем "скользящий массив", т.к. pos идёт от 0..n
    static long long dpCur[3][2], dpNext[3][2];
    memset(dpCur, 0, sizeof(dpCur));
    dpCur[0][0] = 1; // в начале не поставили ни одной "простой" и "не меньше"

    // Множество разрешённых цифр
    // (0,4,6,8,9 не используем, т.к. тогда произведение не было бы простым)
    // (1 — разрешена, не влияет на произведение, 2,3,5,7 — допустимые "примы")
    vector<int> allowed = {1,2,3,5,7};

    for(int pos = 0; pos < n; pos++){
        memset(dpNext, 0, sizeof(dpNext));
        for(int used = 0; used < 3; used++){     // 0..2
            for(int less = 0; less < 2; less++){ // 0..1
                long long ways = dpCur[used][less];
                if (!ways) continue;

                int limit = (less ? 9 : digits[pos]);
                // перебираем, какую цифру поставим на позицию pos
                for(int d: allowed){
                    if(d > limit) break; // т.к. allowed отсортирован по возрастанию
                    int newUsed = used;
                    if(d == 2 || d == 3 || d == 5 || d == 7){
                        // добавляем "прим-цифру"
                        if (used == 0) newUsed = 1;
                        else if (used == 1) {
                            // тогда это было бы уже вторая "прим-цифра" => invalid
                            newUsed = 2; 
                        }
                    }
                    if(newUsed == 2) {
                        // не даём переход, т.к. нам нужно ровно одну "прим-цифру"
                        continue;
                    }
                    int newLess = less || (d < limit ? 1 : 0);
                    dpNext[newUsed][newLess] += ways;
                }
            }
        }
        // переходим к следующему разряду
        memcpy(dpCur, dpNext, sizeof(dpCur));
    }

    // Итог: количество вариантов, где used=1 (ровно одна простая цифра),
    // при less=0 или 1.
    long long res = dpCur[1][0] + dpCur[1][1];
    return res;
}

/*
  Возвращает число "простоватых" чисел (любых длин) в диапазоне [1 .. X].
  Если X == "0", возвращаем 0.
*/
long long countUpTo(const string &X) {
    // Если X == "0", значит нет положительных чисел <= 0
    if (X == "0") return 0;

    // длина X
    long long n = (long long)X.size();
    // 1) Сумма по длинам < n
    long long result = sumForLengths(n); 
    // Внимание: sumForLengths(n) даёт сумму 4L для L=1..(n-1).
    // Но формула 2(n-1)n как раз это и считает.
    // Для n=1 sumForLengths(1)=0 (всё верно).

    // 2) Добавляем количество простоватых чисел ровно длины n, не превосходящих X
    result += countLengthNUpTo(X);

    return result;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string l, r;
    cin >> l >> r;

    // Считаем количество простоватых чисел в [l, r] = countUpTo(r) - countUpTo(l-1).
    // Осторожно обходим случай l=1:
    //  - Если l = "1", то (l-1) = "0".
    //  - Если l > "1", делаем вычитание по decimal-строке.

    // Функция для вычитания 1
    auto lMinusOne = (l == "1" ? string("0") : subtractOne(l));

    long long ans = countUpTo(r) - countUpTo(lMinusOne);
    cout << ans << "\n";
    return 0;
}
