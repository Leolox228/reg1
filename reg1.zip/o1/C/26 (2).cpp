#include <bits/stdc++.h>
using namespace std;

// Структура для хранения "сжатого" описания сегмента (run-length encoding).
struct Segment {
    // RLE: каждая пара (h, c) означает c подряд идущих блоков высоты h.
    // Пример: [(2,3), (5,2), (1,4)]
    vector<pair<long long, long long>> rle;
    // Суммарная длина сегмента (количество блоков).
    long long totalLen = 0;
    // Предвычисленная "ёмкость" (объём воды) в данном сегменте.
    long long water = 0;
};

// Строим сегмент из одного блока высоты h_i.
Segment buildSingle(long long h) {
    Segment seg;
    seg.rle.push_back({h, 1});
    seg.totalLen = 1;
    seg.water = 0; // в одном блоке воды быть не может
    return seg;
}

// Двухпроходный расчёт воды для RLE-сегмента
long long computeWater(const vector<pair<long long,long long>> &rle) {
    int k = (int)rle.size();
    if (k <= 1) return 0;  // Если одна "пара" или пусто — воды нет
    // Подготовим массивы для max слева-направо и справа-налево
    vector<long long> leftMax(k), rightMax(k);
    leftMax[0] = rle[0].first;
    for(int i=1; i<k; i++){
        leftMax[i] = max(leftMax[i-1], rle[i].first);
    }
    rightMax[k-1] = rle[k-1].first;
    for(int i=k-2; i>=0; i--){
        rightMax[i] = max(rightMax[i+1], rle[i].first);
    }
    // Считаем суммарный объём
    long long totalWater = 0;
    for(int i=0; i<k; i++){
        long long mh = min(leftMax[i], rightMax[i]);
        long long d = mh - rle[i].first; // если mh > высоты
        if(d > 0){
            totalWater += d * rle[i].second; 
        }
    }
    return totalWater;
}

// Слияние RLE-массивов A и B: B идёт справа. 
// После слияния в A пишем результат (новый RLE и water).
void mergeSegments(Segment &A, const Segment &B){
    // 1) Сцепляем rle
    //    Если последняя высота A совпадает с первой высотой B, сольём их в один блок
    //    Например, A: [..., (5, 3)], B: [(5, 2), (2,4)] => объединяем (5,3) + (5,2).
    A.rle.reserve(A.rle.size() + B.rle.size()); 
    if(!A.rle.empty() && !B.rle.empty()){
        // попробуем слить "хвост" A и "голову" B
        if(A.rle.back().first == B.rle.front().first){
            A.rle.back().second += B.rle.front().second;
            // добавим остальные пары из B.rle, пропустив первую
            for(int i=1; i<(int)B.rle.size(); i++){
                A.rle.push_back(B.rle[i]);
            }
        } else {
            // просто конкатенируем
            for(auto &p : B.rle){
                A.rle.push_back(p);
            }
        }
    } else {
        // Если A пуст, просто копируем B
        for(auto &p : B.rle){
            A.rle.push_back(p);
        }
    }
    // 2) Увеличить длину
    A.totalLen += B.totalLen;
    // 3) Пересчитать воду в новом сегменте
    A.water = computeWater(A.rle);
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<long long> h(n);
    for(int i=0; i<n; i++){
        cin >> h[i];
    }
    vector<int> mergeInstr(n-1);
    for(int i=0; i<n-1; i++){
        cin >> mergeInstr[i];
    }

    // Изначально у нас n сегментов (каждый из одного блока).
    // Сложим их в std::list, чтобы потом сливать соседей.
    list<Segment> segments;
    segments.resize(n);
    {
        // Заполним по данным h
        auto it = segments.begin();
        for(int i=0; i<n; i++, ++it){
            *it = buildSingle(h[i]);
        }
    }

    // Теперь обрабатываем n-1 инструкции.
    // Для простоты каждый раз будем идти к k-му сегменту через std::advance.
    // Это, увы, может дать O(n^2) на поиск. Для больших n придётся
    // делать индексированную структуру. Но здесь — демонстрационная реализация.
    for(int step=0; step<(n-1); step++){
        int k = mergeInstr[step]; // 1-based индекс сегмента
        // Найдём итератор на (k)-й сегмент
        // (в текущей нумерации, слева направо).
        auto it = segments.begin();
        advance(it, k-1);  // теперь it указывает на k-й сегмент
        auto itNext = next(it); // k+1-й сегмент

        // Сольём их: segments[k] <- merge( segments[k], segments[k+1] )
        mergeSegments(*it, *itNext);

        // Выводим емкость нового объединённого сегмента
        cout << it->water << "\n";

        // Удаляем второй сегмент (k+1) из списка
        segments.erase(itNext);
    }

    return 0;
}
