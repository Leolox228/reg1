#include <bits/stdc++.h>
using namespace std;

//---------------------------------------------------------------------
// 1) Структура, описывающая один "сегмент" (сжатый профиль + вода).
//    Здесь для простоты храним обычный вектор всех высот; это наивно!
//    Для O(n log n) нужны более продвинутые структуры (RLE/монотонные стековые профили и т.п.),
//    которые можно сливать "амортизированно" за O(#вершин), не пересчитывая весь массив.
//---------------------------------------------------------------------

struct Segment {
    // Наивно храним все блоки сегмента: O(|seg|) памяти...
    // В реальном решении — здесь будет структура (RLE/monotonic profile).
    vector<long long> blocks;
    // Предвычисленное количество воды
    long long water = 0;
};

// Простейшая "Trapping Rain Water" на всём массиве.
static long long computeWaterNaive(const vector<long long> &arr) {
    int n = (int)arr.size();
    if(n < 3) return 0; // минимум 2 блока => воды не будет
    vector<long long> L(n), R(n);
    L[0] = arr[0];
    for(int i=1; i<n; i++){
        L[i] = max(L[i-1], arr[i]);
    }
    R[n-1] = arr[n-1];
    for(int i=n-2; i>=0; i--){
        R[i] = max(R[i+1], arr[i]);
    }
    long long ans = 0;
    for(int i=0; i<n; i++){
        long long level = min(L[i], R[i]);
        if(level > arr[i]) ans += (level - arr[i]);
    }
    return ans;
}

// Слияние сегмента A и B (B идёт справа).
// Здесь - наивная реализация, склеиваем векторы -> пересчёт воды за O(|A|+|B|).
void mergeSegments(Segment &A, const Segment &B){
    // Добавляем блоки B в конец A
    A.blocks.insert(A.blocks.end(), B.blocks.begin(), B.blocks.end());
    // Пересчитываем воду (НАИВНО!).
    A.water = computeWaterNaive(A.blocks);
}

//---------------------------------------------------------------------
// 2) Treap (неявный ключ): каждый узел соответствует РОВНО ОДНОМУ сегменту
//---------------------------------------------------------------------

struct Node {
    // Указатели на детей
    Node* l = nullptr;
    Node* r = nullptr;
    // Приоритет для Treap
    int prior;
    // Число узлов в поддереве (кол-во сегментов в поддереве)
    int sz;
    
    // Собственно "полезная" часть - наш Segment
    Segment seg;

    Node(const Segment &s) {
        seg = s;
        // случайный приоритет
        prior = rand();
        // в поддереве - 1 узел (сам)
        sz = 1;
    }
};

// Функция для пересчёта sz, если левые/правые дети могли измениться
static void update_size(Node* v){
    if(!v) return;
    v->sz = 1; 
    if(v->l) v->sz += v->l->sz;
    if(v->r) v->sz += v->r->sz;
}

// Разделяет дерево `root` на два: в `L` попадут первые `key` узлов (по порядку),
// в `R` — остальные. Неявный ключ = "порядковый номер узла в поддереве".
pair<Node*, Node*> split(Node* root, int key) {
    // Если дерево пустое — обе части пусты
    if(!root) return {nullptr, nullptr};
    
    // Сколько узлов в левом поддереве?
    int left_size = (root->l ? root->l->sz : 0);
    
    if(left_size >= key) {
        // Значит, надо "откусить" часть слева
        auto p = split(root->l, key);
        root->l = p.second;
        update_size(root);
        return {p.first, root};
    } else {
        // Надо откусить справа
        auto p = split(root->r, key - (left_size+1));
        root->r = p.first;
        update_size(root);
        return {root, p.second};
    }
}

// Сливает два treap'а L и R, где все узлы в L идут "до" всех узлов в R
Node* mergeTreaps(Node* L, Node* R) {
    if(!L) return R;
    if(!R) return L;
    
    if(L->prior > R->prior) {
        L->r = mergeTreaps(L->r, R);
        update_size(L);
        return L;
    } else {
        R->l = mergeTreaps(L, R->l);
        update_size(R);
        return R;
    }
}

// Возвращает указатель на k-й узел (1-базовый индекс среди поддерева root)
Node* get_kth(Node* root, int k){
    // Идём по дереву, "расщепляя" по размерам
    if(!root) return nullptr; 
    int left_size = (root->l ? root->l->sz : 0);
    if(k == left_size+1){
        return root;
    } else if(k <= left_size){
        return get_kth(root->l, k);
    } else {
        return get_kth(root->r, k - (left_size+1));
    }
}

// Построение treap из массива/вектора Segment-ов (в порядке слева-направо)
// Можно за O(n) *average-case*, если рандомные приоритеты в порядке...
// Для простоты сделаем наивно: вставлять по одному.
Node* buildTreap(const vector<Segment> &arr){
    srand(0);  // для воспроизводимости (можно убрать)
    Node* root = nullptr;
    for(auto &s : arr){
        Node* v = new Node(s);
        // вставим в конец (mergeTreaps(root, v))
        root = mergeTreaps(root, v);
    }
    return root;
}

//---------------------------------------------------------------------
// 3) Основная программа
//---------------------------------------------------------------------

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    srand(0); // фиксируем, чтобы тесты были детерминированными

    int n;
    cin >> n;
    vector<long long> h(n);
    for(int i=0; i<n; i++){
        cin >> h[i];
    }
    vector<int> mergeInstr(n-1);
    for(int i=0; i<n-1; i++){
        cin >> mergeInstr[i];
    }

    // Шаг 1: построим список из n сегментов (каждый по одному блоку),
    //        потом слепим Treap
    vector<Segment> initSeg(n);
    for(int i=0; i<n; i++){
        initSeg[i].blocks.push_back(h[i]);
        initSeg[i].water = 0; // один блок не удерживает воду
    }
    Node* root = buildTreap(initSeg);

    // Шаг 2: Выполняем n-1 слияние
    //   Для каждого запроса k: слить k-й сегмент и (k+1)-й сегмент
    //   1) Найти указатель на k-й узел: get_kth(root, k)
    //   2) И на (k+1)-й узел: get_kth(root, k+1)
    //   3) mergeSegments(...) внутри
    //   4) Удалить (k+1)-й узел из дерева
    //   5) Вывести water

    for(int step = 0; step < n-1; step++){
        int k = mergeInstr[step];  // 1-based индекс сегмента

        // Узлы, соответствующие k-му и (k+1)-му сегменту
        Node* X = get_kth(root, k);
        Node* Y = get_kth(root, k+1);

        // Сливаем их "Segment"
        mergeSegments(X->seg, Y->seg);

        // Удаляем Y из дерева
        //   Для удаления: split по k+1, split вторую часть по 1, выбросить узел
        //   root = L + R2
        auto p1 = split(root, k);     // p1.first = [1..k], p1.second = [k+1..end]
        auto p2 = split(p1.second, 1); 
        Node* toDelete = p2.first; 
        // p2.second = [k+2..end]
        // "toDelete" это узел Y, нам его нужно убрать (delete)
        // но в задаче можно не освобождать (если не критична память).
        // Главное - он не должен участвовать в дереве.

        // Собираем дерево обратно: p1.first уже содержит X, но X->seg обновлён.
        root = mergeTreaps(p1.first, p2.second);

        // Выводим обновлённое количество воды в X->seg
        cout << X->seg.water << "\n";
    }

    return 0;
}
