#include <bits/stdc++.h>
using namespace std;

// Функция, вычисляющая "количество воды" в подмассиве h[L..R].
long long water_on_segment(const vector<long long> &h, int L, int R) {
    int m = R - L + 1;
    vector<long long> leftMax(m), rightMax(m);
    
    // Массив максимумов слева-направо
    leftMax[0] = h[L];
    for (int i = 1; i < m; i++) {
        leftMax[i] = max(leftMax[i-1], h[L + i]);
    }
    
    // Массив максимумов справа-налево
    rightMax[m - 1] = h[R];
    for (int i = m - 2; i >= 0; i--) {
        rightMax[i] = max(rightMax[i + 1], h[L + i]);
    }
    
    // Считаем суммарную воду
    long long res = 0;
    for (int i = 0; i < m; i++) {
        long long level = min(leftMax[i], rightMax[i]);
        if (level > h[L + i]) {
            res += (level - h[L + i]);
        }
    }
    return res;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;            // Число блоков
    vector<long long> h(n);
    for(int i = 0; i < n; i++){
        cin >> h[i];     // Высота i-го блока
    }

    // Считываем n-1 инструкцию
    vector<int> mergeInstr(n - 1);
    for(int i = 0; i < n - 1; i++){
        cin >> mergeInstr[i];
    }

    // Изначально имеем n сегментов: (0,0), (1,1), ..., (n-1,n-1).
    // Будем хранить их в векторе pairs: (start, end).
    // Нумерацию инструкций (k_j) учтём как 1-базную внутри массива segments.
    vector<pair<int,int>> segments(n);
    for(int i = 0; i < n; i++){
        segments[i] = make_pair(i, i);
    }

    // Обрабатываем n-1 слияние.
    for(int step = 0; step < n - 1; step++){
        int k = mergeInstr[step]; // это значение k_j из условия (1-базовая нумерация сегментов)
        // Но вектор segments у нас 0-базный, значит индекс сегмента = k - 1
        // В текущем состоянии сегментов их меньше, поэтому всё корректно.
        int idx = k - 1;  // сегмент, который сливаем с сегментом idx+1

        // Берём границы сливаемых сегментов
        auto [L1, R1] = segments[idx];
        auto [L2, R2] = segments[idx + 1];

        // Новый объединённый сегмент = (L1, R2)
        int newL = min(L1, L2);
        int newR = max(R1, R2);

        // Вычисляем "ёмкость" получившегося сегмента
        long long w = water_on_segment(h, newL, newR);

        // Выводим результат
        cout << w << "\n";

        // Записываем новый сегмент на место старого
        segments[idx] = make_pair(newL, newR);

        // Удаляем следующий сегмент, так как он теперь объединился
        segments.erase(segments.begin() + (idx + 1));
    }

    return 0;
}
