#include <bits/stdc++.h>
using namespace std;

static const int MOD = 1000000007;

// Глобальные переменные для удобства
int n, k;
vector<long long> b; // b_1.. b_n

// Храним для каждой маски m (0..2^k-1) массив ps[m][r], r=0..k
// где ps[m][r] = число единиц в верхних r ячейках (r=0 => 0).
// ps[m][k] = число единиц во всем столбце.
static int ps[1<<7][8];

// Мы хотим хранить в DP состояние (a_1.. a_{k-1}),
// где a_i = partialSum( c-i, k-i ), лежит в [0..(k-i)].
// Сгенерируем все такие k-1-мерные кортежи, запишем их в массив states.
// И сделаем map<tuple, int> -> index.
vector< vector<int> > states; // states[idx] = { a_1, a_2, ..., a_{k-1} }
unordered_map<string,int> stIndex; // или другой способ кодирования

// Быстрая функция для "кодирования" a_1.. a_{k-1} в string/int
// Здесь для упрощения - string; на практике лучше вручную в int.
string encodeTuple(const vector<int> &vals){
    // k-1 <= 6 (если k=7). Сложим в char?
    // Упрощенно, сделаем через delimiters:
    // (Но лучше придумать более быстрый encode.)
    // Заметим, a_i <= k, k<=7 => a_i <=7
    // Можно упаковать в 3 бита на элемент => 18 бит => int.
    // Здесь - демонстрационно:
    ostringstream oss;
    for(int x: vals){
        oss << x << ",";
    }
    return oss.str();
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n >> k;
    b.resize(n+1);
    for(int i=1; i<=n; i++){
        cin >> b[i];
    }

    // Предвычислим ps[m][r] для всех масок m
    // Пусть бит 0 - самая верхняя строка, бит (k-1) - самая нижняя.
    // (Важно быть последовательным потом!)
    // ps[m][0] = 0
    // ps[m][r] = ps[m][r-1] + (m имеет 1 на бит позиции (r-1)?)
    for(int m=0; m < (1<<k); m++){
        ps[m][0] = 0;
        int acc=0;
        for(int r=1; r<=k; r++){
            int bitIdx = r-1; // r=1 => bit 0 => "верхняя"
            int bitVal = ((m >> bitIdx) & 1);
            acc += bitVal;
            ps[m][r] = acc;
        }
    }

    // Сгенерируем все допустимые (a_1.. a_{k-1}).
    // a_i \in [0..(k-i)].
    // Сохраним в "states".
    // Также построим обратный индекс stIndex[ encodeTuple(...) ] = idx.
    {
        vector<int> cur(k-1, 0);
        // Рекурсивно/итеративно обойдем все варианты
        // Можно сделать простой вложенный цикл глубины (k-1),
        // так как k <=7 - это не слишком много.
        // Демонстративно - рекурсия:
        function<void(int)> dfs = [&](int pos){
            if(pos == k-1){
                string s = encodeTuple(cur);
                int idx = states.size();
                states.push_back(cur);
                stIndex[s] = idx;
                return;
            }
            int i = pos+1;    // i = номер a_i (1..k-1)
            int maxVal = k - i; // a_i <= k-i
            for(int val=0; val<=maxVal; val++){
                cur[pos] = val;
                dfs(pos+1);
            }
        };
        dfs(0);
    }
    int S = (int)states.size(); // = k! (для k=7 => 5040)

    // dp[c][st] = число способов расставить столбцы 1..c,
    // имея вектор (a_1.. a_{k-1}) = states[st].
    // Реализуем "скользящий массив" по c: dpCur[S], dpNext[S].
    vector<long long> dpCur(S, 0), dpNext(S, 0);

    // Найдём индекс "стартового" state = (0,0,...,0).
    vector<int> zeroVec(k-1, 0);
    string zS = encodeTuple(zeroVec);
    int startState = stIndex[zS];
    dpCur[startState] = 1;

    // Основной цикл по c: от 0 до n-1, где c=число уже заполненных столбцов.
    // Переход к c+1 => мы добавляем столбец (c+1)-й.
    for(int c=0; c<n; c++){
        // очистим dpNext
        for(int st=0; st<S; st++){
            dpNext[st] = 0;
        }
        // перебираем все состояния oldState
        for(int oldSt=0; oldSt<S; oldSt++){
            long long ways = dpCur[oldSt];
            if(!ways) continue;

            // Раскодируем a_1.. a_{k-1}
            const auto &arr = states[oldSt]; // a_1.. a_{k-1}
            // переберём все варианты маски p для столбца c+1
            for(int p=0; p<(1<<k); p++){
                // Вычислим scanSum = ps[p][k] + sum_{i=1..min(k-1,c)} a_i
                long long alpha = ps[p][k]; // кол-во 1 в новом столбце
                int limit = min(k-1, c); // если c < k-1, часть сумм не участвует
                long long scanSum = alpha;
                for(int i=1; i<=limit; i++){
                    scanSum += arr[i-1]; // a_i = arr[i-1] (сдвиг на -1)
                }
                // сравним с b[c+1], т.к. нумерация b с 1, а c идёт с 0
                if(scanSum != b[c+1]) continue; // не подходит

                // если подходит, формируем newState => (a'_1.. a'_{k-1})
                // a'_1 = ps[p][k-1],
                // a'_2 = a_1 = arr[0],
                // a'_3 = a_2 = arr[1],
                // ...
                // a'_{k-1} = a_{k-2} = arr[k-2 - 1], но только если k-2 >=1.
                vector<int> arr2(k-1);
                if(k>1) arr2[0] = ps[p][k-1]; // partialSum(новый столбец, k-1)
                for(int i=2; i<=k-1; i++){
                    arr2[i-1] = arr[i-2]; 
                }
                // закодим arr2
                string s2 = encodeTuple(arr2);
                int newSt = stIndex[s2];
                // обновим dpNext[newSt]
                long long &ref = dpNext[newSt];
                ref = (ref + ways) % MOD;
            }
        }
        // dpNext становится dpCur
        dpCur.swap(dpNext);
    }

    // В конце ответ - сумма dpCur[st] по всем st
    long long ans = 0;
    for(int st=0; st<S; st++){
        ans = (ans + dpCur[st]) % MOD;
    }
    cout << ans << "\n";
    return 0;
}
