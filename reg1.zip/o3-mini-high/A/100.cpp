#include <iostream>
#include <algorithm>
using namespace std;
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    // Read board dimensions and maximum jump length.
    long long n, m, k;
    cin >> n >> m >> k;
    
    // Calculate the required displacements.
    long long dx = n - 1; // horizontal displacement
    long long dy = m - 1; // vertical displacement
    
    // If no displacement is needed, answer is 0.
    if(dx == 0 && dy == 0) {
        cout << 0;
        return 0;
    }
    
    // Let d be the common part that can be covered by diagonal moves.
    long long d = min(dx, dy);
    long long D = max(dx, dy);
    
    // Compute the number of moves:
    // - moves for the common (diagonal) part.
    // - moves for the remaining part.
    long long movesDiag = (d + k - 1) / k;          // ceil(d/k)
    long long movesStraight = ((D - d) + k - 1) / k;  // ceil((D-d)/k)
    
    cout << movesDiag + movesStraight;
    return 0;
}
