#include <bits/stdc++.h>
using namespace std;
 
// Function to subtract 1 from a positive integer given in string form.
string decStr(const string &s) {
    string res = s;
    int i = res.size()-1;
    while(i >= 0 && res[i]=='0'){
        res[i] = '9';
        i--;
    }
    if(i >= 0){
        res[i] = char(res[i]-1);
    }
    // Remove any leading zeros (but leave one digit if the result is 0)
    int pos = 0;
    while(pos < (int)res.size()-1 && res[pos]=='0')
        pos++;
    return res.substr(pos);
}
 
// Function f: returns count of valid "простоватые" numbers <= X,
// where X is given as a string (without leading zeros).
long long f(const string &X) {
    // if X is "0", then no valid numbers.
    if(X == "0") return 0;
    int m = X.size();
    // For one-digit numbers, the only valid numbers are 2,3,5,7.
    if(m == 1){
        int x = X[0]-'0';
        long long ans = 0;
        if(x >= 2) ans++;
        if(x >= 3) ans++;
        if(x >= 5) ans++;
        if(x >= 7) ans++;
        return ans;
    }
    // Count of all valid numbers with fewer than m digits.
    long long res = 2LL * m * (m - 1); // since sum_{n=1}^{m-1} (4*n) = 2*m*(m-1)
 
    // Now, count valid numbers of length m that are <= X.
    // Let T be the m-digit string.
    const string &T = X;
    // Find first index k where T[k] != '1'
    int k = -1;
    for (int i = 0; i < m; i++){
        if(T[i] != '1'){
            k = i;
            break;
        }
    }
    // If no such index exists then T is "111...1".
    // But any valid m-digit candidate must have one digit > '1', so they are all > T.
    if(k == -1) return res;
 
    int x = T[k]-'0';
    if(x <= 1) {
        // (Should not happen because by definition T[k] != '1'.)
        return res;
    }
    long long g = 0;
    // For candidates where the differing digit is at a position i > k,
    // the candidate S has S[j] = '1' for j <= k.
    // At index k: S[k] = '1' but T[k] = x > 1, so S < T regardless of the rest.
    // There are (m - k - 1) such positions and 4 choices for each.
    g += 4LL * (m - k - 1);
 
    // For candidates with the differing position exactly k:
    int count_k = 0;
    int primes[4] = {2,3,5,7};
    for (int d : primes) {
        if(d < x) {
            // If d is less than x, then S[k] < T[k] and S < T.
            count_k++;
        } else if(d == x) {
            // When d equals T[k], we need to check the suffix.
            bool suffixOk = true;
            // Suffix of candidate is all '1's.
            for (int j = k+1; j < m; j++){
                char candDigit = '1';
                if(candDigit < T[j]){
                    // As soon as candidate's digit is less, S < T.
                    break;
                } else if(candDigit > T[j]){
                    suffixOk = false;
                    break;
                }
                // if equal, continue checking.
            }
            if(suffixOk)
                count_k++;
        }
        // If d > x then candidate S > T.
    }
    g += count_k;
 
    res += g;
    return res;
}
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
    string l, r;
    cin >> l >> r;
    // We want the count of valid numbers in [l, r] = f(r) - f(l-1).
    string lminus = (l == "1" ? "0" : decStr(l));
    long long ans = f(r) - f(lminus);
    cout << ans << "\n";
    return 0;
}
