#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN = 100005;
const int LOGN = 18; // 2^17 = 131072 > 100000

int n;
ll h[MAXN];         // высоты блоков (индексы 1..n)
ll P[MAXN];         // префиксные суммы: P[0] = 0, P[i] = h[1] + ... + h[i]

// Для каждой позиции i:
// nexArr[i] = минимальный j > i, такой что h[j] > h[i] (если нет – n+1)
int nexArr[MAXN];
// pgeArr[i] = максимальный j < i, такой что h[j] > h[i] (если нет – 0)
int pgeArr[MAXN];

// --- Бинарное прыжковое представление для F_query (слева) ---
int jump[MAXN][LOGN];
ll cost[MAXN][LOGN];

// Аналогично для обратной цепочки (для правой части G_query)
int rjump[MAXN][LOGN];
ll rcost[MAXN][LOGN];

// --- Sparse table для RMQ ---
// st[i][j] = индекс максимума в отрезке, начинающемся с i, длины 2^j.
int st[MAXN][LOGN];
int logVal[MAXN];

// Предобработка: Sparse table
void buildSparseTable(){
    for (int i = 1; i <= n; i++){
        st[i][0] = i;
    }
    for (int j = 1; (1 << j) <= n; j++){
        for (int i = 1; i + (1 << j) - 1 <= n; i++){
            int i1 = st[i][j-1];
            int i2 = st[i + (1 << (j-1))][j-1];
            st[i][j] = (h[i1] >= h[i2] ? i1 : i2);
        }
    }
    logVal[1] = 0;
    for (int i = 2; i <= n; i++){
        logVal[i] = logVal[i/2] + 1;
    }
}

// RMQ-запрос: возвращает индекс максимума на отрезке [L,R]
int queryRMQ(int L, int R){
    int j = logVal[R - L + 1];
    int i1 = st[L][j];
    int i2 = st[R - (1 << j) + 1][j];
    return (h[i1] >= h[i2] ? i1 : i2);
}

// Функция для поиска первого индекса с h[i] > X на отрезке [L,R]
int find_first_greater(int L, int R, ll X){
    int idxMax = queryRMQ(L, R);
    if(h[idxMax] <= X) return R+1;
    int lo = L, hi = R;
    while(lo < hi){
        int mid = (lo + hi) / 2;
        int idx = queryRMQ(L, mid);
        if(h[idx] > X)
            hi = mid;
        else
            lo = mid + 1;
    }
    return lo;
}

// Дерево Фенвика для динамических сегментов
struct Fenw {
    int n;
    vector<int> fenw;
    Fenw(int n) : n(n) {
        fenw.assign(n+1, 0);
    }
    void init(vector<int> &arr) {
        for (int i = 1; i <= n; i++){
            fenw[i] = arr[i];
        }
        for (int i = 1; i <= n; i++){
            int j = i + (i & -i);
            if(j <= n)
                fenw[j] += fenw[i];
        }
    }
    void update(int i, int delta) {
        for(; i <= n; i += i & -i)
            fenw[i] += delta;
    }
    int sum(int i) {
        int s = 0;
        for(; i > 0; i -= i & -i)
            s += fenw[i];
        return s;
    }
    // Находим минимальный индекс i, такой что сумма fenw[1..i] >= k.
    int findKth(int k) {
        int idx = 0;
        for (int bit = 1 << 17; bit; bit >>= 1){
            int next = idx + bit;
            if(next <= n && fenw[next] < k){
                k -= fenw[next];
                idx = next;
            }
        }
        return idx + 1;
    }
};

// Структура для сегмента (отрезок исходных блоков)
struct Segment {
    int L, R;
};

// Предобработка: вычисляем массивы nexArr и pgeArr
void computeNexPge(){
    stack<int> stck;
    // Вычисляем nexArr: идём с i = n ... 1.
    for (int i = n; i >= 1; i--){
        while(!stck.empty() && h[stck.top()] <= h[i])
            stck.pop();
        nexArr[i] = (stck.empty() ? n+1 : stck.top());
        stck.push(i);
    }
    while(!stck.empty()) stck.pop();
    // Вычисляем pgeArr: идём с i = 1 ... n.
    for (int i = 1; i <= n; i++){
        while(!stck.empty() && h[stck.top()] <= h[i])
            stck.pop();
        pgeArr[i] = (stck.empty() ? 0 : stck.top());
        stck.push(i);
    }
}

// Построение бинарных таблиц для F_query и G_query
void buildBinaryLifting(){
    // Для F_query (слева)
    for (int i = 1; i <= n; i++){
        jump[i][0] = nexArr[i];
        int nxt = (nexArr[i] <= n ? nexArr[i] : n+1);
        cost[i][0] = (ll)h[i] * (nxt - i);
    }
    for (int k = 1; k < LOGN; k++){
        for (int i = 1; i <= n; i++){
            int nxt = jump[i][k-1];
            if(nxt <= n) {
                jump[i][k] = jump[nxt][k-1];
                cost[i][k] = cost[i][k-1] + cost[nxt][k-1];
            } else {
                jump[i][k] = n+1;
                cost[i][k] = cost[i][k-1];
            }
        }
    }
    // Для G_query (справа): используем pgeArr.
    for (int i = 1; i <= n; i++){
        rjump[i][0] = pgeArr[i];
        int prev = (pgeArr[i] > 0 ? pgeArr[i] : 0);
        rcost[i][0] = (ll)h[i] * (i - prev);
    }
    for (int k = 1; k < LOGN; k++){
        for (int i = 1; i <= n; i++){
            int rj = rjump[i][k-1];
            if(rj > 0) {
                rjump[i][k] = rjump[rj][k-1];
                rcost[i][k] = rcost[i][k-1] + rcost[rj][k-1];
            } else {
                rjump[i][k] = 0;
                rcost[i][k] = rcost[i][k-1];
            }
        }
    }
}

// F_query: для отрезка [i, M] считаем сумму Lmax для p = i..M
ll F_query(int i, int M){
    ll ans = 0;
    int cur = i;
    for (int k = LOGN-1; k >= 0; k--){
        if(jump[cur][k] <= M){
            ans += cost[cur][k];
            cur = jump[cur][k];
        }
    }
    ans += (ll)h[cur] * (M - cur + 1);
    return ans;
}

// G_query: для отрезка [M, i] считаем сумму Rmax для p = M..i
ll G_query(int i, int M){
    ll ans = 0;
    int cur = i;
    for (int k = LOGN-1; k >= 0; k--){
        if(rjump[cur][k] >= M && rjump[cur][k] != 0){
            ans += rcost[cur][k];
            cur = rjump[cur][k];
        }
    }
    ans += (ll)h[cur] * (cur - M + 1);
    return ans;
}

// Функция waterCapacity(L, R): вычисление ёмкости сегмента [L,R]
ll waterCapacity(int L, int R){
    if(L > R) return 0;
    int m = queryRMQ(L, R);
    ll leftSum = F_query(L, m);
    ll rightSum = G_query(R, m);
    ll tot = P[R] - P[L-1];
    ll w = leftSum + rightSum - h[m] - tot;
    return w;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n;
    for (int i = 1; i <= n; i++){
        cin >> h[i];
    }
    // Префиксные суммы:
    P[0] = 0;
    for (int i = 1; i <= n; i++){
        P[i] = P[i-1] + h[i];
    }

    // Предобработка:
    computeNexPge();
    buildBinaryLifting();
    buildSparseTable();

    // Чтение инструкций объединения (n-1 штук).
    vector<int> merges(n-1);
    for (int i = 0; i < n-1; i++){
        cin >> merges[i];
    }

    // Изначально каждый блок — отдельный сегмент [i, i].
    vector<Segment> segs(n+1);
    vector<int> activeArr(n+1, 0); // active[i] = 1, если сегмент i активен
    for (int i = 1; i <= n; i++){
        segs[i].L = i;
        segs[i].R = i;
        activeArr[i] = 1;
    }

    // Инициализация дерева Фенвика.
    Fenw fenw(n);
    fenw.init(activeArr);

    // Обрабатываем объединения.
    // Каждая инструкция содержит число k — надо объединить k-й и (k+1)-й активные сегменты.
    for (int i = 0; i < n-1; i++){
        int k = merges[i];
        int idx1 = fenw.findKth(k);     // индекс первого сегмента по текущей нумерации
        int idx2 = fenw.findKth(k+1);     // индекс следующего сегмента
        int L = segs[idx1].L;
        int R = segs[idx2].R;

        ll water = waterCapacity(L, R);
        cout << water << "\n";

        // Обновляем: новый сегмент записываем в segs[idx1]
        segs[idx1].L = L;
        segs[idx1].R = R;
        // Помечаем сегмент segs[idx2] как неактивный
        fenw.update(idx2, -1);
    }

    return 0;
}
