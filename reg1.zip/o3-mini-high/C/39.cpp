#include <bits/stdc++.h>
using namespace std;
 
// ------------------------
// Segment structure and envelope routines
// ------------------------
 
// In a contiguous segment S (with blocks of width 1) the water–capacity is defined as:
//    W = (sum_{i in S} min(L_i, R_i)) - (sum_{i in S} h_i)
// where L_i = max{ h_l, h_{l+1}, …, h_i } and R_i = max{ h_i, …, h_r }.
// 
// In order to merge two segments quickly we “compress” the left and right running–max functions
// into piecewise–constant envelopes. (Each envelope is stored as a vector of pairs (value, count)
// whose total “count” equals the segment length.)
 
struct Seg {
    int len;              // number of blocks in this segment
    long long sum;        // sum of block heights
    long long maxVal;     // maximum block height in the segment
    // left envelope: running maximum when scanning from the left.
    // Stored as a vector of (value, count) pairs (in left–to–right order).
    vector<pair<long long,int>> leftEnv;
    // right envelope: running maximum when scanning from the right,
    // stored in left–to–right order (so it is non–increasing).
    vector<pair<long long,int>> rightEnv;
    long long T;          // silhouette = sum_{i=1}^{len} min(leftMax[i], rightMax[i])
};
 
// Merge two envelope vectors by simple concatenation then “compress” (merge adjacent equal pairs).
vector<pair<long long,int>> mergeEnvs(const vector<pair<long long,int>> &A, const vector<pair<long long,int>> &B) {
    vector<pair<long long,int>> res;
    res = A;
    for(auto &p : B){
        if(!res.empty() && res.back().first == p.first)
            res.back().second += p.second;
        else
            res.push_back(p);
    }
    return res;
}
 
// Transform an envelope V: replace every value v with max(X, v)
vector<pair<long long,int>> transformEnv(const vector<pair<long long,int>> &V, long long X) {
    vector<pair<long long,int>> res;
    for(auto &p : V){
        long long nv = p.first;
        if(nv < X) nv = X;
        if(!res.empty() && res.back().first == nv)
            res.back().second += p.second;
        else
            res.push_back({nv, p.second});
    }
    return res;
}
 
// Given two envelopes L and R (which describe functions on an interval of length = sum of counts),
// compute sum_{i} min( f(i), g(i) ) by a two–pointer method.
long long combineEnvs(const vector<pair<long long,int>> &L, const vector<pair<long long,int>> &R) {
    long long res = 0;
    int i = 0, j = 0;
    int remL = (i < (int)L.size() ? L[i].second : 0);
    int remR = (j < (int)R.size() ? R[j].second : 0);
    while(i < (int)L.size() && j < (int)R.size()){
        int d = min(remL, remR);
        long long level = min(L[i].first, R[j].first);
        res += level * (long long)d;
        remL -= d;
        remR -= d;
        if(remL == 0){
            i++;
            if(i < (int)L.size()) remL = L[i].second;
        }
        if(remR == 0){
            j++;
            if(j < (int)R.size()) remR = R[j].second;
        }
    }
    return res;
}
 
// Merge two segments A and B (A comes before B) into one segment S.
Seg mergeSeg(const Seg &A, const Seg &B) {
    Seg S;
    S.len = A.len + B.len;
    S.sum = A.sum + B.sum;
    S.maxVal = max(A.maxVal, B.maxVal);
    // Build left envelope for S:
    // For blocks from A, take A.leftEnv as is;
    // For blocks from B, the left–max becomes max(A.maxVal, original).
    vector<pair<long long,int>> transB = transformEnv(B.leftEnv, A.maxVal);
    S.leftEnv = mergeEnvs(A.leftEnv, transB);
 
    // Build right envelope for S:
    // For blocks from A, the right–max becomes max(B.maxVal, original).
    // For blocks from B, take B.rightEnv as is.
    vector<pair<long long,int>> transA = transformEnv(A.rightEnv, B.maxVal);
    S.rightEnv = mergeEnvs(transA, B.rightEnv);
 
    // Compute silhouette T.
    S.T = combineEnvs(S.leftEnv, S.rightEnv);
    return S;
}
 
// For a single block with height h, create a segment.
Seg makeSeg(long long h) {
    Seg s;
    s.len = 1;
    s.sum = h;
    s.maxVal = h;
    s.leftEnv.push_back({h,1});
    s.rightEnv.push_back({h,1});
    s.T = h; // for a single block, silhouette = h.
    return s;
}
 
// ------------------------
// Treap (order–statistic tree) for maintaining the current list of segments
// ------------------------
 
struct Node {
    Seg seg;
    int sz;
    int prior;
    Node *l, *r;
    Node(const Seg &s) : seg(s), sz(1), prior(rand()), l(nullptr), r(nullptr) { }
};
 
int getSize(Node* t) {
    return t ? t->sz : 0;
}
 
void upd(Node* t) {
    if(t) t->sz = 1 + getSize(t->l) + getSize(t->r);
}
 
// Merge two treaps L and R (all keys in L come before those in R)
Node* mergeTreap(Node* L, Node* R) {
    if(!L || !R) return L ? L : R;
    if(L->prior < R->prior) {
        L->r = mergeTreap(L->r, R);
        upd(L);
        return L;
    } else {
        R->l = mergeTreap(L, R->l);
        upd(R);
        return R;
    }
}
 
// Split treap t into L and R so that L has first k nodes (by order) and R has the rest.
void splitTreap(Node* t, int k, Node* &L, Node* &R) {
    if(!t){ L = R = nullptr; return; }
    int leftSize = getSize(t->l);
    if(leftSize >= k){
        splitTreap(t->l, k, L, t->l);
        R = t;
        upd(R);
    } else {
        splitTreap(t->r, k - leftSize - 1, t->r, R);
        L = t;
        upd(L);
    }
}
 
// Get the k–th node (0-indexed) from treap t.
Node* getKth(Node* t, int k) {
    if(!t) return nullptr;
    int leftSize = getSize(t->l);
    if(k < leftSize) return getKth(t->l, k);
    else if(k == leftSize) return t;
    else return getKth(t->r, k - leftSize - 1);
}
 
// ------------------------
// Main
// ------------------------
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
    int n; 
    cin >> n;
    vector<long long> h(n);
    for (int i = 0; i < n; i++){
        cin >> h[i];
    }
    // Build initial treap: each block is its own segment.
    Node* root = nullptr;
    for (int i = 0; i < n; i++){
        Seg seg = makeSeg(h[i]);
        Node* newNode = new Node(seg);
        root = mergeTreap(root, newNode);
    }
 
    // There are n-1 merge instructions.
    int mCount = n - 1;
    vector<int> merges(mCount);
    for (int i = 0; i < mCount; i++){
        cin >> merges[i];
    }
 
    // Process each merge instruction.
    // (Each instruction: merge the k-th and (k+1)-th segments in the current order.)
    for (int i = 0; i < mCount; i++){
        int k = merges[i]; // k is 1-indexed; valid: 1 <= k <= (current number of segments - 1)
        Node *Ltree = nullptr, *Mtree = nullptr, *Rtree = nullptr;
        // Split so that Ltree has the first (k-1) segments.
        splitTreap(root, k-1, Ltree, Rtree);
        // Then split Rtree so that the next 2 segments are in Mtree.
        splitTreap(Rtree, 2, Mtree, Rtree);
 
        // Mtree now contains exactly 2 nodes.
        Node* firstNode = getKth(Mtree, 0);
        Node* secondNode = getKth(Mtree, 1);
 
        // Merge the two segments.
        Seg mergedSeg = mergeSeg(firstNode->seg, secondNode->seg);
 
        // The water capacity for the merged segment is (mergedSeg.T - mergedSeg.sum).
        long long waterCap = mergedSeg.T - mergedSeg.sum;
        cout << waterCap << "\n";
 
        // Create a new node for the merged segment.
        Node* newNode = new Node(mergedSeg);
 
        // (We don’t worry too much about freeing memory in contest code.)
        delete firstNode;
        delete secondNode;
 
        // Reassemble the treap.
        root = mergeTreap( mergeTreap(Ltree, newNode), Rtree );
    }
 
    // Clean up treap memory.
    function<void(Node*)> delTreap = [&](Node* t){
        if(!t) return;
        delTreap(t->l);
        delTreap(t->r);
        delete t;
    };
    delTreap(root);
 
    return 0;
}
