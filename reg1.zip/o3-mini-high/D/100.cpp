#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
 
const ll MOD = 1000000007;
 
// Функция для кодирования вектора состояния (каждый элемент занимает 8 бит) в 64‑битное число.
ll encodeState(const vector<int>& state) {
    ll code = 0;
    int L = state.size();
    for (int i = 0; i < L; i++){
        code |= ((ll) state[i] & 0xFFLL) << (8 * i);
    }
    return code;
}
 
// Функция для декодирования состояния из 64‑битного числа.
vector<int> decodeState(ll code, int L) {
    vector<int> state(L, 0);
    for (int i = 0; i < L; i++){
        state[i] = (int)((code >> (8 * i)) & 0xFFLL);
    }
    return state;
}
 
// Основная программа
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
    int n, k;
    cin >> n >> k;
    vector<int> b(n);
    for (int i = 0; i < n; i++){
        cin >> b[i];
    }
 
    // Для каждого столбца представляем шаблон как число из 0..(2^k-1).
    // Для каждого шаблона вычисляем вектор v длины k:
    // v[0] = popcount(pattern) – число единиц во всём столбце,
    // v[1] = popcount(pattern в верхних k-1 строках),
    // ...
    // v[j] = popcount(pattern в верхних (k-j) строках).
    int totalPatterns = 1 << k;
    // Группируем шаблоны по значению v[0]
    vector<vector<vector<int>>> groups(k+1); // groups[r] – список векторов v для шаблонов, где v[0]==r.
    for (int mask = 0; mask < totalPatterns; mask++){
        vector<int> v(k, 0);
        for (int j = 0; j < k; j++){
            int bitsToConsider = k - j;
            int submask = mask & ((1 << bitsToConsider) - 1);
            v[j] = __builtin_popcount(submask);
        }
        int fullCount = v[0]; // число единиц во всём столбце.
        groups[fullCount].push_back(v);
    }
 
    // Динамика: будем перебирать столбцы от 1 до n.
    // Состояние – вектор S длины L = k-1, где S[0] – сумма вкладов из предыдущих столбцов,
    // которые надо прибавить к уравнению для текущего столбца.
    int L = k - 1;
 
    // dp[i] – число способов назначить шаблоны для столбцов 1..(i-1), имея состояние для столбца i.
    // Начальное состояние (i=1): пустой вклад – вектор длины L, заполненный нулями.
    unordered_map<ll, ll> cur;
    vector<int> initState(L, 0);
    cur[ encodeState(initState) ] = 1;
 
    // Обработка столбцов 1..n
    for (int col = 1; col <= n; col++){
        unordered_map<ll, ll> nxt;
        for (auto &entry : cur) {
            ll stateCode = entry.first;
            ll ways = entry.second;
            vector<int> state = decodeState(stateCode, L);
            // Для столбца col уравнение:
            // state[0] + v[0] = b[col-1]
            int required = b[col-1] - ( (L > 0 ? state[0] : 0) );
            if(required < 0 || required > k) continue;
 
            // Перебираем все шаблоны, у которых v[0] равно required.
            for (auto &v : groups[required]) {
                // Новый столбец выбирается с вкладом v = (v[0], v[1], …, v[k-1]).
                // Обновляем состояние для следующего столбца.
                // Новое состояние T длины L: для j от 0 до L-2, T[j] = (state[j+1] + v[j+1]);
                // для j = L-1: T[L-1] = v[L] (так как state[L] нет).
                vector<int> newState(L, 0);
                for (int j = 0; j < L; j++){
                    int addFromOld = 0;
                    if(j+1 < L) {
                        addFromOld = state[j+1];
                    }
                    int addFromNew = v[j+1]; // поскольку v имеет длину k = L+1.
                    newState[j] = addFromOld + addFromNew;
                }
                ll newCode = encodeState(newState);
                nxt[newCode] = (nxt[newCode] + ways) % MOD;
            }
        }
        cur = move(nxt);
    }
 
    // После обработки всех столбцов (col = n+1) все уравнения удовлетворены.
    ll ans = 0;
    for (auto &entry : cur){
        ans = (ans + entry.second) % MOD;
    }
    cout << ans % MOD << "\n";
    return 0;
}
