#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
const ll MOD = 1000000007;
 
// effectivePop[X][L] = popcount( X restricted to первые L битов )
// Для k<=7 достаточно, поэтому размер таблицы небольшой.
int effectivePop[1<<10][11];
 
// Для каждого количества единиц от 0 до k будем хранить все паттерны X (от 0 до 2^k-1) с popcount(X)==r.
vector<vector<int>> popList;
 
// --- Кодирование состояния ---
// Состояние – вектор целых чисел (паттернов) для активных столбцов. Максимальная длина состояния = k-1 (при k>=2).
// Мы будем кодировать его в число типа uint64_t в виде k байт: 
// первый байт – длина (0..k-1), далее ровно k-1 байт: если элемент есть, записываем (X+1) (так X из 0..2^k-1, а X+1 лежит в 1..2^k), иначе 0.
 
uint64_t encodeState(const vector<int> &state, int k) {
    int totalBytes = k; // при k>=2: state имеет длину от 0 до k-1.
    uint64_t key = 0;
    int len = state.size();
    key = (uint64_t) len;  // первый байт – длина
    for (int i = 0; i < totalBytes - 1; i++) {
        key = (key << 8);
        if(i < len){
            key |= (uint64_t)(state[i] + 1);
        } else {
            key |= 0;
        }
    }
    return key;
}
 
vector<int> decodeState(uint64_t key, int k) {
    int totalBytes = k;
    vector<uint8_t> bytes(totalBytes, 0);
    for (int i = totalBytes - 1; i >= 0; i--) {
        bytes[i] = key & 0xFF;
        key >>= 8;
    }
    int len = bytes[0];
    vector<int> state(len);
    for (int i = 0; i < len; i++){
        state[i] = (int)bytes[i+1] - 1;
    }
    return state;
}
 
// Основная программа
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
    int n, k;
    cin >> n >> k;
    vector<int> b(n);
    for (int i = 0; i < n; i++){
        cin >> b[i];
    }
 
    // Обработка случая k == 1 отдельно.
    if(k == 1){
        ll ways = 1;
        for (int i = 0; i < n; i++){
            int x = b[i];
            if(x < 0 || x > 1){ ways = 0; break; }
            // При k==1 единственный паттерн: 0 (если x==0) или 1 (если x==1)
        }
        cout << ways % MOD << "\n";
        return 0;
    }
 
    // k >= 2.
    int totalPatterns = 1 << k;
    popList.assign(k+1, vector<int>());
    for (int X = 0; X < totalPatterns; X++){
        int cnt = __builtin_popcount(X);
        popList[cnt].push_back(X);
    }
 
    // Предвычисляем effectivePop:
    // Для каждого X (паттерна столбца) и для каждого L от 0 до k, считаем popcount( X & ((1<<L)-1) ).
    for (int X = 0; X < totalPatterns; X++){
        for (int L = 0; L <= k; L++){
            int mask = (L == 0 ? 0 : ((1 << L) - 1));
            effectivePop[X][L] = __builtin_popcount(X & mask);
        }
    }
 
    // Организуем ДП по столбцам.
    // dp[p] – после обработки p столбцов (0 ≤ p ≤ n) наше состояние (для сканирования столбца p+1).
    // Заметим: если p < k, то состояние содержит p столбцов; если p ≥ k, то состояние имеет ровно k-1 элементов.
    vector<unordered_map<uint64_t, ll>> dp(n+1);
    dp[0].clear();
    vector<int> initState; // пустое состояние
    uint64_t initKey = encodeState(initState, k);
    dp[0][initKey] = 1;
 
    // Переходим по столбцам: p = 0,...,n-1; текущий считываемый столбец имеет номер P = p+1.
    for (int p = 0; p < n; p++){
        for (auto &entry : dp[p]){
            uint64_t stateKey = entry.first;
            ll ways = entry.second;
            vector<int> state = decodeState(stateKey, k);
            int m = state.size(); // число активных столбцов.
            // Для состояния state элементы соответствуют столбцам: P-m, P-m+1, …, P-1.
            // Для i-го элемента (0-indexed) его "возраст" равен m - i, а вклад = effectivePop[state[i]][k - (m - i)].
            int A = 0;
            for (int i = 0; i < m; i++){
                int effLen = k - (m - i); // эквивалентно k - m + i
                A += effectivePop[state[i]][effLen];
            }
            // Требование сканера для столбца P (P = p+1): A + popcount(X) = b[p]  (так как b[0] – считывание для 1-го столбца)
            int needed = b[p] - A;
            if(needed < 0 || needed > k) continue;
 
            // Перебираем все паттерны X длины k с popcount(X)==needed.
            for (int X : popList[needed]){
                vector<int> newState;
                if(m < k - 1){
                    newState = state;
                    newState.push_back(X);
                } else {
                    // m == k-1, старейший столбец пропадает.
                    newState.assign(state.begin()+1, state.end());
                    newState.push_back(X);
                }
                uint64_t newKey = encodeState(newState, k);
                dp[p+1][newKey] = (dp[p+1][newKey] + ways) % MOD;
            }
        }
    }
 
    ll ans = 0;
    for (auto &entry : dp[n]){
        ans = (ans + entry.second) % MOD;
    }
    cout << ans % MOD << "\n";
 
    return 0;
}
