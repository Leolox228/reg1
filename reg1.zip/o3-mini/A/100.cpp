#include <bits/stdc++.h>
using namespace std;

// Функция целочисленного деления вверх: ceil(x / y) для неотрицательных x,y
long long ceilDiv(long long x, long long y) {
    return (x + y - 1) / y;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m, k;
    cin >> n >> m >> k;

    // Если мы уже в правом верхнем углу (n,m) == (1,1)
    if (n == 1 && m == 1) {
        cout << 0 << "\n";
        return 0;
    }

    // Разницы по вертикали и горизонтали
    long long a = n - 1; 
    long long b = m - 1;
    
    // Меньшая и большая из разниц
    long long s = min(a, b);
    long long l = max(a, b);

    // Сколько ходов нужно, чтобы покрыть меньшую разницу диагоналями
    long long diagMoves = ceilDiv(s, k);

    // Сколько ходов, чтобы добрать остаток в большей разнице
    long long singleMoves = ceilDiv(l - s, k);

    // Итог
    cout << diagMoves + singleMoves << "\n";
    return 0;
}
