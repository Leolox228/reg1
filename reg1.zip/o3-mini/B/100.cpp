#include <bits/stdc++.h>
using namespace std;

// Считаем (n-1)*n/2 * 4 = 2*n*(n-1) для суммы
static long long countShorterNumbers(int length) {
    if (length <= 0) return 0; // нет положительных длиной < 1
    long long L = length;
    // Сумма 4 * (1 + 2 + ... + (L - 1)) = 4 * (L-1)*L/2 = 2*(L-1)*L
    // но надо для L-1, а не L (если length=1, цикл пуст)
    long long n = L - 1; // длины от 1 до L-1
    if (n <= 0) return 0;
    long long result = 2LL * n * (n+1); 
    // Подробно: sum_{d=1}^{n} d = n*(n+1)/2 => умножаем на 4 => 2*n*(n+1).
    // Но здесь "n" = (L-1).
    return result;
}

// Глобальные ограничения на размер DP: до 100000 цифр, нужно dp[pos][usedPrime][isTight].
static const int MAXLEN = 100000;

// Вспомогательная функция для digit-DP
long long dfsDP(int pos, bool usedPrime, bool isTight,
                const vector<int>& digits,
                vector<vector<vector<long long>>>& dpVal,
                vector<vector<vector<bool>>>& used) 
{
    if (pos == (int)digits.size()) {
        // Дошли до конца — засчитываем число только если уже была одна "простая" цифра
        return (usedPrime ? 1LL : 0LL);
    }
    if (used[pos][usedPrime][isTight]) {
        return dpVal[pos][usedPrime][isTight];
    }
    used[pos][usedPrime][isTight] = true;

    long long ans = 0;
    int limitDig = (isTight ? digits[pos] : 9);

    if (!usedPrime) {
        // Можно выбрать цифру 1 или одну из {2,3,5,7}, если <= limitDig
        static const int candidates[5] = {1, 2, 3, 5, 7};
        for (int d: candidates) {
            if (d <= limitDig) {
                bool nextUsedPrime = (usedPrime || d != 1);
                bool nextTight = (isTight && d == limitDig);
                ans += dfsDP(pos+1, nextUsedPrime, nextTight, digits, dpVal, used);
            }
        }
    } else {
        // usedPrime==true => оставшиеся цифры могут быть только 1
        // иначе получим 2 или более "простых" цифр
        int d = 1;
        if (d <= limitDig) {
            bool nextTight = (isTight && d == limitDig);
            ans += dfsDP(pos+1, true, nextTight, digits, dpVal, used);
        }
    }

    dpVal[pos][usedPrime][isTight] = ans;
    return ans;
}

// Считает количество "простоватых" чисел ровно с той же длиной, которые <= x
long long countSameLength(const string &x) {
    // Преобразуем x в вектор цифр
    vector<int> digits(x.size());
    for (int i = 0; i < (int)x.size(); i++) {
        digits[i] = x[i] - '0';
    }
    // Подготовим dp
    int L = (int)x.size();
    vector<vector<vector<long long>>> dpVal(L, vector<vector<long long>>(2, vector<long long>(2, -1)));
    // Чтобы экономить память, можно использовать отдельный массив used:
    vector<vector<vector<bool>>> used(L, vector<vector<bool>>(2, vector<bool>(2, false)));

    // Запустим рекурсивную функцию
    return dfsDP(0, false, true, digits, dpVal, used);
}

// Основная функция: считает, сколько "простоватых" чисел <= x (x может быть очень большим)
long long countUpTo(const string &x) {
    // Если x < "1", то результат 0
    // Удобно проверить, не является ли x "0" или пустой.
    // По условию l>=1, но нам нужно уметь считать countUpTo(l-1).
    // Считаем, что если x == "0" или " ", то возвращаем 0.
    // Или если длина x == 1 и x[0]=='0'
    if (x == "0" || x.empty()) {
        return 0;
    }
    // Уберём ведущие нули, если вдруг они есть (по условию не должны, но на всякий случай).
    // Если в итоге строка станет "0", вернём 0.
    int idx = 0;
    while (idx < (int)x.size() && x[idx] == '0') {
        idx++;
    }
    if (idx == (int)x.size()) {
        // было только "0"...
        return 0;
    }
    // Теперь x[idx..end-1] — строка без ведущих нулей
    string trimx = x.substr(idx);

    int L = (int)trimx.size();
    // Считаем все простоватые числа меньшей длины
    long long ans = countShorterNumbers(L);

    // + количество простоватых чисел ровно длины L, но <= trimx
    ans += countSameLength(trimx);

    return ans;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string l, r;
    cin >> l >> r;

    // countUpTo(r) - countUpTo(l-1)
    // нужно аккуратно получить (l-1) как строку (big integer вычитание).
    // Если l=="1", то l-1 = "0".
    // Вспомогательная функция bigDec().
    
    // Вычтем 1 из l, если l> "1". Иначе результат "0".
    auto bigDec = [&](const string &s) {
        // Вычесть 1 из s ( s >= "1" ).
        // Результат не будет содержать ведущих нулей, если s>"1".
        // Если s=="1", вернёт "0".
        // Реализуем обычное "столбиковое" вычитание.
        if (s == "0") return string("0"); // на всякий случай
        if (s == "1") return string("0");

        // s > "1"
        string result = s;
        int i = (int)result.size()-1;
        while (i >= 0) {
            if (result[i] == '0') {
                result[i] = '9';
                i--;
            } else {
                result[i] = char(result[i] - 1);
                break;
            }
        }
        // Удалим ведущие нули, если появились
        while (result.size() > 1 && result[0] == '0') {
            result.erase(result.begin());
        }
        return result;
    };

    // l - 1
    string lminus1 = (l == "1" ? "0" : bigDec(l));

    long long ans = countUpTo(r) - countUpTo(lminus1);
    cout << ans << "\n";
    return 0;
}
