#include <bits/stdc++.h>
using namespace std;

/*
  ЗАДАЧА "Кислотные дожди"

  - n блоков, высоты h[1..n]
  - n-1 инструкций: объединить сегмент №k_j со следующим (k_j+1)
  - После каждого объединения вывести "ёмкость" объединённого сегмента
  - В итоге все блоки объединятся в один.
  
  РЕШЕНИЕ за O(n log n) с помощью:
   1) Fenwick (BIT) для быстрого поиска позиции сегмента и удаления
   2) Построения "дерева слияний" (2n-1 узлов)
   3) Постордерного обхода с "small-to-large" merge профилей (trap water стек).
*/

// ---------------------------------------------------
// Fenwick Tree (BIT) для поддержки массива из n единиц
// - sum(i): сумма на отрезке [1..i]
// - update(i, delta): прибавить delta к элементу i
// - findKth(k): найти минимальный i, что sum(i) = k
//   (k всегда корректен, 1 <= k <= кол-во ещё не удалённых).
// ---------------------------------------------------
struct Fenwick {
    int n;
    vector<int> fenw;
    Fenwick(int n_) : n(n_), fenw(n_+1, 0) {}

    void initAllOnes() {
        // Примем, что изначально все позиции [1..n] = 1
        // Тогда fenw[i] = число 1-иц на отрезке [i - (i&-i) +1 .. i]
        // Можно либо циклом update( i, +1 ), либо хитрее.
        // Проще сделать циклом - O(n log n) - приемлемо для 1e5.
        for(int i=1; i<=n; i++){
            update(i, 1);
        }
    }

    void update(int i, int delta){
        for(; i<=n; i+=(i & -i)){
            fenw[i] += delta;
        }
    }

    int sum(int i) const {
        int s=0; 
        for(; i>0; i-=(i & -i)){
            s += fenw[i];
        }
        return s;
    }

    // find i such that sum(i) = k  (1 <= k <= total number of 1's left)
    // Предполагается, что решение всегда есть. 
    // Классический двоичный поиск "Fenwick" (или BIT).
    int findKth(int k){
        // ищем минимальный i, s.t. sum(i) >= k
        // но легче шаблон: мы идем от MSB к LSB
        int pos=0;
        for(int bit=(1<<20); bit>0; bit>>=1){
            int nxt=pos+bit;
            if(nxt<=n && fenw[nxt]<k){
                k -= fenw[nxt];
                pos = nxt;
            }
        }
        return pos+1;
    }
};

// ---------------------------------------------------
// Описание узла "дерева слияний"
//   id           : индекс вершины (1..n - это листья, n+1..n+(n-1) - внутр. узлы)
//   mergeIndex   : =0 у листа, иначе номер шага объединения (1..n-1)
//   leftChild,rightChild : дети (0, если нет)
// ---------------------------------------------------
static const int MAXN = 100000;
struct Node {
    int id;            // 1..n листья, n+1..2n-1 внутренние
    int mergeIndex;    // 0 у листа, иначе = j (номер слияния)
    int leftChild, rightChild;
};

// Глобальные массивы / данные
int n;
long long h[2*MAXN + 5];   // высоты для листьев (h[1..n]) 
                           // (для внутренних узлов h[...] не используется)

Node tree[2*MAXN + 5];     // дерево: 1..n - листы, n+1..n+(n-1) - внутренние
long long ans[MAXN+5];     // ans[j] = ёмкость после j-го слияния

// В rep[pos] храним "корень" сегмента, который сейчас занимает "позицию pos" 
// (1 <= pos <= n в смысле Fenwick - позиция слева-направо среди живых).
int rep[2*MAXN + 5];

// ---------------------------------------------------
// Для вычисления "ёмкости" сегмента используем классический стековый 
// алгоритм trap-water, но нам нужно многократное слияние.
//
// "Профиль" будет хранить:
//  - вектор st = stack = монотонно возрастающие по высоте вершины
//      каждый элемент: (indexInSegment, blockHeight)
//    indexInSegment идёт слева-направо от 0..(size-1)
//  - totalWater : суммарная вода над этим сегментом
//
// Мы сольём два профиля (левый, правый) так, будто мы итерируем 
// слева-направо по всем блокам (сначала левый, потом правый, 
// но индексы у правого сдвинуты).
//
// При "small-to-large" мы будем дописывать маленький профиль блок за блоком 
// в конец большого, чтобы итоговая асимптотика была O(n log n).
// ---------------------------------------------------
struct Profile {
    // Храним (index, height) в порядке слева-направо
    // Высоты возрастают "по стеку": top().second самая большая в стеке.
    vector<pair<int,int>> st; 
    long long totalWater = 0;
    int size() const { return (int)st.size(); }
};

long long addBlock(Profile &P, int newIndex, int newHeight) {
    // Добавляет блок (newIndex, newHeight) в стек P.st "как при trap-water"
    // Возвращает, сколько воды добавилось при этом "всплытии".
    long long gained = 0;
    auto &st = P.st;
    while(!st.empty() && st.back().second <= newHeight) {
        auto mid = st.back(); 
        st.pop_back();
        if(st.empty()) break;
        // mid - "нижний пик"
        // st.back() - "левый пик" (top after pop)
        // (newIndex, newHeight) - "правый пик"
        long long leftH = st.back().second;
        long long rightH = newHeight;
        long long hMin = min(leftH, rightH);
        long long hMid = mid.second;
        if(hMin > hMid) {
            long long width = (long long)(newIndex - st.back().first - 1);
            gained += (hMin - hMid)*width;
        }
    }
    st.push_back({newIndex, newHeight});
    return gained;
}

// Слияние двух профилей (левый A, правый B) => новый профиль C.
// Возвращаем C, а его totalWater = A.totalWater + B.totalWater + "стык".
Profile mergeProfiles(Profile &A, Profile &B) {
    // small-to-large: пусть M = bigger, S = smaller
    // Но нам важно, что итоговый порядок блоков: сначала A, потом B (индексы со сдвигом).
    // Реализуем "полный" проход: 
    //   Создаём C пустой, подряд "закидываем" все блоки из A (с их индексацией 0..A.size-1), 
    //   затем блоки из B (со сдвигом = A.size()).
    Profile C;
    C.totalWater = 0;
    C.st.reserve(A.size() + B.size()); // во избежание лишних реаллокаций

    // функция локальная: добавляет блок (idx, h) в C, пересчитывая воду
    auto pushBlockToC = [&](int idx, int hh){
        long long g = addBlock(C, idx, hh);
        C.totalWater += g;
    };

    // "выливаем" A:
    // индексы A идут от 0..(A.size()-1) как есть
    C.totalWater = 0; // сначала 0, далее будет накапливаться
    for (auto &p: A.st) {
        // p.first — уже 0..(A.size-1), p.second — высота
        pushBlockToC(p.first, p.second);
    }
    // Но нужно добавить воду, которая уже была "внутри" A
    C.totalWater += A.totalWater;

    // "выливаем" B:
    // индексы B сдвигаем на shift = A.size()
    int shift = A.size();
    for (auto &p: B.st) {
        int newI = shift + p.first;
        pushBlockToC(newI, p.second);
    }
    // Добавляем воду из B
    C.totalWater += B.totalWater;

    return C;
}

// ---------------------------------------------------
// Построим профиль узла v рекурсивно (постордер).
//  - если v - лист (mergeIndex=0, нет детей), профиль = один блок
//  - иначе: профиль = merge( build(leftChild), build(rightChild) )
// После склейки сохраняем water в ans[ mergeIndex(v) ].
//
// Итог: profile[v] - большой объект, но суммарная длина всех профилей ~ O(n log n).
// ---------------------------------------------------
Profile buildProfile(int v){
    // Лист?
    if(tree[v].mergeIndex == 0 && tree[v].leftChild==0 && tree[v].rightChild==0) {
        // У листа id in [1..n], h[v] - его высота
        Profile pf;
        pf.st.push_back({0, (int)h[v]}); // один элемент (индекс=0, высота)
        pf.totalWater = 0;
        return pf;
    }
    // Внутренний узел
    int L = tree[v].leftChild;
    int R = tree[v].rightChild;
    Profile leftP = buildProfile(L);
    Profile rightP = buildProfile(R);

    Profile merged = mergeProfiles(leftP, rightP);
    int j = tree[v].mergeIndex; // номер слияния
    ans[j] = merged.totalWater;  // после j-го слияния
    return merged;
}

// ---------------------------------------------------
// Главный solve()
// ---------------------------------------------------
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n;
    for(int i=1; i<=n; i++){
        cin >> h[i];
        // Узел-«лист»
        tree[i].id = i;
        tree[i].mergeIndex = 0;  // признак листа
        tree[i].leftChild = 0;
        tree[i].rightChild= 0;
    }

    vector<int> K(n-1);
    for(int j=0; j<n-1; j++){
        cin >> K[j];
    }

    // Fenwick для позиций [1..n]
    Fenwick fenw(n);
    fenw.initAllOnes(); 

    // Изначально rep[i] = i (корень сегмента = лист)
    // т.к. у нас n сегментов, каждый из одного блока
    for(int i=1; i<=n; i++){
        rep[i] = i;  // "корень" = узел i
    }

    // Cоздаём внутренние узлы с id от n+1 до n+(n-1)
    int nextID = n+1;
    
    // Обработка n-1 слияния
    for(int j=1; j<=n-1; j++){
        int kPos = K[j-1]; // какое слияние делаем (k_j)
        // Найти позицию leftPos в Fenwick, чтобы sum(leftPos)=kPos
        int leftPos = fenw.findKth(kPos);

        // Правый сегмент - это сосед справа => это (leftPos+1) в логике "живых"
        // Убеждаемся, что он существует (kPos <= тек. кол-во сегментов - 1)
        // В задаче гарантировано корректно.
        int rightPos = leftPos + 1; 

        // Корни сегментов
        int leftRoot = rep[leftPos];
        int rightRoot= rep[rightPos];

        // Создаём новый узел
        int newNode = nextID++;
        tree[newNode].id = newNode;
        tree[newNode].mergeIndex = j;  // это j-е слияние
        tree[newNode].leftChild  = leftRoot;
        tree[newNode].rightChild = rightRoot;

        // Новый узел заменяет левый сегмент 
        rep[leftPos] = newNode;

        // Правый сегмент "исчезает" (мы его объединили).  
        fenw.update(rightPos, -1); // снимаем 1 с позиции rightPos

        // Идём дальше
    }

    // Остался ровно 1 активный сегмент. Найдём его позицию.
    // Там fenw.sum(pos)=1, значит total=1, findKth(1).
    int finalPos = fenw.findKth(1);
    int root = rep[finalPos];

    // Построим профиль для root (постордер) и заодно заполним ans[].
    buildProfile(root);

    // Выводим ans[1..n-1]
    for(int j=1; j<=n-1; j++){
        cout << ans[j] << "\n";
    }

    return 0;
}
