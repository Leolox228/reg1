#include <bits/stdc++.h>
using namespace std;
 
// Функция для вычисления накоплённой жидкости (ёмкости) для заданной гистограммы.
// Реализована по алгоритму двух указателей – классическое решение задачи "trapping rain water".
long long computeWater(const vector<int>& blocks) {
    if(blocks.size() < 3) return 0;
    int l = 0, r = blocks.size()-1;
    int leftMax = blocks[l], rightMax = blocks[r];
    long long water = 0;
    while(l < r){
        if(blocks[l] < blocks[r]){
            l++;
            if(blocks[l] > leftMax)
                leftMax = blocks[l];
            else
                water += (long long) leftMax - blocks[l];
        } else {
            r--;
            if(blocks[r] > rightMax)
                rightMax = blocks[r];
            else
                water += (long long) rightMax - blocks[r];
        }
    }
    return water;
}
 
// Структура, описывающая сегмент: набор блоков и вычисленная ёмкость.
struct Segment {
    vector<int> blocks;
    long long water;
};
 
// Для симуляции объединения сегментов будем хранить их в векторе (в текущей нумерации).
// Каждый сегмент представляется указателем на Node.
struct Node {
    Segment seg;
    Node(const Segment& s) : seg(s) {}
};
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
    int n;
    cin >> n;
    vector<int> h(n);
    for (int i=0; i<n; i++){
        cin >> h[i];
    }
 
    // Читаем последовательность инструкций (n-1 число).
    vector<int> inst(n-1);
    for (int i=0; i<n-1; i++){
        cin >> inst[i];
    }
 
    // Изначально каждый блок – отдельный сегмент.
    vector<Node*> segList;
    segList.reserve(n);
    for (int i=0; i<n; i++){
        Segment s;
        s.blocks.push_back(h[i]);
        s.water = 0; // одиночный блок не вмещает жидкость
        segList.push_back(new Node(s));
    }
 
    // Функция объединения двух соседних сегментов: left и right.
    auto mergeNodes = [&](Node* leftNode, Node* rightNode) -> Node* {
        Segment merged;
        // Объединяем последовательности блоков (порядок не меняется)
        merged.blocks = leftNode->seg.blocks;
        merged.blocks.insert(merged.blocks.end(), rightNode->seg.blocks.begin(), rightNode->seg.blocks.end());
        // Вычисляем ёмкость объединённого сегмента
        merged.water = computeWater(merged.blocks);
        return new Node(merged);
    };
 
    // Обрабатываем инструкции – каждая инструкция даёт номер k, означающий, что надо объединить k-й и (k+1)-й сегменты.
    for (int i=0; i<n-1; i++){
        int pos = inst[i] - 1; // перевод в 0-индексацию
        // pos и pos+1 должны существовать в segList
        Node* leftNode = segList[pos];
        Node* rightNode = segList[pos+1];
 
        Node* mergedNode = mergeNodes(leftNode, rightNode);
 
        // Освобождаем память старых сегментов
        delete leftNode;
        delete rightNode;
 
        // Заменяем сегменты в векторе: удаляем элементы с индексами pos и pos+1 и вставляем новый mergedNode на место pos.
        segList.erase(segList.begin() + pos, segList.begin() + pos + 2);
        segList.insert(segList.begin() + pos, mergedNode);
 
        // Выводим ёмкость полученного сегмента.
        cout << mergedNode->seg.water << "\n";
    }
 
    // Освобождаем оставшиеся сегменты.
    for(auto node : segList)
        delete node;
 
    return 0;
}
