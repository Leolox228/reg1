#include <bits/stdc++.h>
using namespace std;
 
const long long MOD = 1000000007;
 
// Основная идея: для таблицы с k>=2 строк будем использовать DP по столбцам.
// Состояние представлено вектором длины L=k-1, где state[0] – вклад для сканирования текущего столбца,
// а state[j] (j>=1) – вклады, которые появятся через j столбцов.
// При добавлении нового столбца с профилем P = (p0, p1, …, p[k-1])
// условие для текущего столбца: state[0] + p0 = b[col].
// Далее состояние обновляется так: new_state[j] = (j+1< L ? old_state[j+1] : 0) + p[j+1] для j = 0..L-1.
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
    int n, k;
    if(!(cin >> n >> k)) return 1;
    vector<int> b(n);
    for (int i = 0; i < n; i++){
        cin >> b[i];
    }
 
    // Особый случай: k == 1
    if(k == 1){
        long long ways = 1;
        for (int i = 0; i < n; i++){
            // В одном столбце единственная клетка, поэтому b[i] должна быть 0 или 1.
            if(b[i] != 0 && b[i] != 1){
                cout << 0 << "\n";
                return 0;
            }
        }
        cout << ways % MOD << "\n";
        return 0;
    }
 
    // Предварительно перебираем все 2^k вариантов заполнения одного столбца
    // и вычисляем для каждого профиль: P = (p0, p1, …, p[k-1]), где p_d = сумма битов в первых (k-d) клетках.
    // Группируем варианты по значению p0 (количество единиц во всём столбце).
    int totalMasks = 1 << k;
    vector<vector<vector<int>>> groups(k+1); // groups[i] — все профили с p0 = i.
    for (int mask = 0; mask < totalMasks; mask++){
        vector<int> profile(k, 0);
        for (int d = 0; d < k; d++){
            int lim = k - d; // считаем сумму для верхних (k-d) клеток
            int cnt = 0;
            for (int r = 0; r < lim; r++){
                if(mask & (1 << r))
                    cnt++;
            }
            profile[d] = cnt;
        }
        int tot = profile[0];
        if(tot >= 0 && tot <= k)
            groups[tot].push_back(profile);
    }
 
    // Кодирование состояния:
    // Пусть длина состояния L = k-1, каждый элемент от 0 до k, т.е. база B = k+1.
    int L = k - 1, B = k + 1;
    vector<int> powB(L+1, 1);
    for (int i = 1; i <= L; i++){
        powB[i] = powB[i-1] * B;
    }
 
    // DP будем вести по столбцам. Используем два словаря (unordered_map): cur и nxt.
    // Ключ – закодированное состояние, значение – число способов.
    unordered_map<int, long long> cur, nxt;
    cur[0] = 1; // начальное состояние: вектор из L нулей.
 
    for (int col = 0; col < n; col++){
        nxt.clear();
        // Для каждого состояния, накопленный вклад для текущего столбца – цифра с индексом 0 (state % B).
        for (auto &entry : cur){
            int state = entry.first;
            long long ways = entry.second;
            int curContrib = state % B; // вклад, который поступает из предыдущих столбцов для текущего столбца
            // Чтобы сканирование текущего столбца дало b[col], новый столбец должен дать p0 = b[col] - curContrib.
            int required = b[col] - curContrib;
            if(required < 0 || required > k) continue;
 
            // Для каждого профиля с p0 == required перебираем варианты.
            for (auto &prof : groups[required]){
                // Новый столбец имеет профиль prof = (p0, p1, …, p[k-1]).
                // Обновляем состояние: оно будет вектором длины L, где для j=0..L-1:
                // new_state[j] = (если существует old state's digit для j+1, то он, иначе 0) + prof[j+1].
                int newState = 0;
                bool valid = true;
                for (int j = 0; j < L; j++){
                    int oldDigit = 0;
                    if(j+1 < L){
                        oldDigit = (state / powB[j+1]) % B;
                    }
                    int nd = oldDigit + prof[j+1]; // prof[j+1] корректно, т.к. j+1 <= k-1
                    if(nd >= B){ // nd должно быть не больше k
                        valid = false;
                        break;
                    }
                    newState += nd * powB[j];
                }
                if(!valid) continue;
                nxt[newState] = (nxt[newState] + ways) % MOD;
            }
        }
        cur.swap(nxt);
    }
 
    // По условию никаких ограничений на оставшиеся отставшие вклады нет – суммируем все варианты.
    long long ans = 0;
    for (auto &entry : cur){
        ans = (ans + entry.second) % MOD;
    }
    cout << ans % MOD << "\n";
    return 0;
}
