#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    long long n, m, k;
    cin >> n >> m >> k;
    long long a = n - 1;
    long long b = m - 1;
    long long d = min(a, b);
    long long rem = max(a, b) - d;
    long long steps_diag = (d + k - 1) / k;
    long long steps_rem = (rem + k - 1) / k;
    cout << steps_diag + steps_rem << endl;
    return 0;
}