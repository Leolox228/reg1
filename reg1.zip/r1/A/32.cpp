#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    long long n, m, k;
    cin >> n >> m >> k;
    long long dx = n - 1;
    long long dy = m - 1;
    
    if (dx == 0 && dy == 0) {
        cout << 0 << endl;
        return 0;
    }
    if (dx == 0) {
        cout << (dy + k - 1) / k << endl;
        return 0;
    }
    if (dy == 0) {
        cout << (dx + k - 1) / k << endl;
        return 0;
    }
    if (dx <= k && dy <= k) {
        cout << 1 << endl;
        return 0;
    }
    
    long long t1 = (dx + k - 1) / k;
    long long t2 = (dy + k - 1) / k;
    long long t3 = (dx + dy + k) / (k + 1);
    long long ans = max({t1, t2, t3});
    
    cout << ans << endl;
    return 0;
}