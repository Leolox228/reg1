#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    long long n, m, k;
    cin >> n >> m >> k;

    if (n == 1 && m == 1) {
        cout << 0 << endl;
        return 0;
    }

    long long row_needed = n - 1;
    long long col_needed = m - 1;
    int moves = 0;

    while (row_needed > 0 || col_needed > 0) {
        moves++;
        if (row_needed > 0 && col_needed > 0) {
            long long move_len = min({k, row_needed, col_needed});
            row_needed -= move_len;
            col_needed -= move_len;
        } else if (row_needed > 0) {
            long long move_len = min(k, row_needed);
            row_needed -= move_len;
        } else if (col_needed > 0) {
            long long move_len = min(k, col_needed);
            col_needed -= move_len;
        }
    }

    cout << moves << endl;

    return 0;
}