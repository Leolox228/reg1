#include <iostream>
#include <string>
#include <vector>
using namespace std;

bool all_ones(const string &s) {
    for (char c : s) {
        if (c != '1') return false;
    }
    return true;
}

int find_first_not_one(const string &s) {
    for (int i = 0; i < s.size(); ++i) {
        if (s[i] != '1') return i;
    }
    return -1;
}

bool has_less_than_one(const string &s, int start) {
    for (int i = start; i < s.size(); ++i) {
        if (s[i] < '1') return true;
    }
    return false;
}

bool check_ge(int k, int i, int p, const string &bound) {
    for (int j = 0; j < i; ++j) {
        char c = bound[j];
        if (c > '1') return false;
        if (c < '1') return true;
    }
    char ci = bound[i];
    int ci_val = ci - '0';
    if (p < ci_val) return false;
    if (p > ci_val) return true;
    for (int j = i+1; j < k; ++j) {
        char c = bound[j];
        if (c > '1') return false;
        if (c < '1') return true;
    }
    return true;
}

bool check_le(int k, int i, int p, const string &bound) {
    for (int j = 0; j < i; ++j) {
        char c = bound[j];
        if (c < '1') return false;
        if (c > '1') return true;
    }
    char ci = bound[i];
    int ci_val = ci - '0';
    if (p > ci_val) return false;
    if (p < ci_val) return true;
    for (int j = i+1; j < k; ++j) {
        char c = bound[j];
        if (c < '1') return false;
        if (c > '1') return true;
    }
    return true;
}

int main() {
    string l, r;
    cin >> l >> r;
    int len_l = l.size();
    int len_r = r.size();
    if (len_l > len_r) {
        cout << 0 << endl;
        return 0;
    }
    long long ans = 0;
    for (int k = len_l; k <= len_r; ++k) {
        if (k < len_l || k > len_r) continue;
        if (k == len_l && k == len_r) {
            int current = 0;
            for (int i = 0; i < k; ++i) {
                for (int p : {2,3,5,7}) {
                    bool ge = check_ge(k, i, p, l);
                    bool le = check_le(k, i, p, r);
                    if (ge && le) {
                        current++;
                    }
                }
            }
            ans += current;
        } else if (k == len_l) {
            int count_ge_l = 0;
            if (all_ones(l)) {
                count_ge_l = 4 * k;
            } else {
                int pos = find_first_not_one(l);
                if (pos == -1) {
                    count_ge_l = 4 * k;
                } else {
                    if (l[pos] > '1') {
                        count_ge_l = pos * 4;
                    } else {
                        count_ge_l = 4 * k;
                    }
                }
            }
            ans += count_ge_l;
        } else if (k == len_r) {
            int count_le_r = 0;
            if (all_ones(r)) {
                count_le_r = 0;
            } else {
                int pos_r = find_first_not_one(r);
                if (pos_r == -1) {
                    count_le_r = 0;
                } else {
                    if (r[pos_r] < '1') {
                        count_le_r = 0;
                    } else {
                        if (has_less_than_one(r, pos_r + 1)) {
                            count_le_r = 0;
                        } else {
                            int total = 0;
                            for (int i = pos_r; i < k; ++i) {
                                char c = r[i];
                                int cnt = 0;
                                for (int p : {2,3,5,7}) {
                                    if (p <= (c - '0')) {
                                        cnt++;
                                    }
                                }
                                total += cnt;
                            }
                            count_le_r = total;
                        }
                    }
                }
            }
            ans += count_le_r;
        } else {
            ans += 4 * k;
        }
    }
    cout << ans << endl;
    return 0;
}