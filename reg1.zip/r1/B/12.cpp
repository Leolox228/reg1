#include <iostream>
#include <string>
#include <vector>

using namespace std;

int count_greater(char c) {
    if (c == '0' || c == '1') return 4;
    if (c == '2') return 3;
    if (c == '3' || c == '4') return 2;
    if (c == '5' || c == '6') return 1;
    return 0;
}

int count_less_or_eq(char c) {
    if (c < '2') return 0;
    if (c >= '7') return 4;
    if (c >= '5') return 3;
    if (c >= '3') return 2;
    if (c >= '2') return 1;
    return 0;
}

int count_ge(const string &s) {
    int n = s.size();
    if (n == 0) return 0;
    int count = 0;
    int max_prefix = 0;
    while (max_prefix < n && s[max_prefix] == '1') {
        max_prefix++;
    }
    for (int i = 0; i < max_prefix && i < n; ++i) {
        count += count_greater(s[i]);
    }
    if (max_prefix < n) {
        count += count_greater(s[max_prefix]);
    }
    vector<bool> suffix_all_le_one(n + 1, true);
    for (int i = n - 1; i >= 0; --i) {
        if (s[i] > '1') {
            suffix_all_le_one[i] = false;
        } else {
            suffix_all_le_one[i] = suffix_all_le_one[i + 1];
        }
    }
    for (int i = 0; i < n; ++i) {
        if (s[i] == '2' || s[i] == '3' || s[i] == '5' || s[i] == '7') {
            if (i + 1 >= n || suffix_all_le_one[i + 1]) {
                count++;
            }
        }
    }
    return count;
}

int count_le(const string &s) {
    int n = s.size();
    if (n == 0) return 0;
    vector<int> prefix_zero(n + 1, 0);
    for (int i = 0; i < n; ++i) {
        prefix_zero[i + 1] = prefix_zero[i] + (s[i] == '0' ? 1 : 0);
    }
    int count = 0;
    for (int i = 0; i < n; ++i) {
        char c = s[i];
        int less_eq = count_less_or_eq(c);
        count += less_eq;
        if (c == '2' || c == '3' || c == '5' || c == '7') {
            int a = i + 1;
            int b = n - 1;
            bool has_zero = false;
            if (a <= b) {
                int zeros = prefix_zero[b + 1] - prefix_zero[a];
                has_zero = (zeros > 0);
            }
            if (!has_zero) {
                count++;
            }
        }
    }
    return count;
}

bool is_primovatoe(const string &s) {
    int total_ones = 0;
    int other_count = 0;
    char other_char = ' ';
    for (char c : s) {
        if (c == '1') {
            total_ones++;
        } else {
            other_count++;
            other_char = c;
        }
    }
    if (other_count != 1) return false;
    return (other_char == '2' || other_char == '3' || other_char == '5' || other_char == '7');
}

int main() {
    string l, r;
    cin >> l >> r;

    int len_l = l.size();
    int len_r = r.size();

    long long answer = 0;

    for (int n = len_l; n <= len_r; ++n) {
        if (n < len_l || n > len_r) continue;

        if (n > len_l && n < len_r) {
            answer += 4LL * n;
        } else if (n == len_l && n == len_r) {
            int cnt_ge_l = count_ge(l);
            int cnt_le_r = count_le(r);
            bool r_prim = is_primovatoe(r);
            answer += cnt_ge_l - (count_ge(r) - (r_prim ? 1 : 0));
        } else if (n == len_l) {
            answer += count_ge(l);
        } else if (n == len_r) {
            answer += count_le(r);
        }
    }

    cout << answer << endl;

    return 0;
}