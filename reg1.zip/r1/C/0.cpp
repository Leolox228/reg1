#include <iostream>
#include <vector>
using namespace std;

struct Segment {
    int l, r;
};

int calculate_capacity(const vector<int>& h, int l, int r) {
    int sum = 0;
    int n = r - l + 1;
    vector<int> left_max(n);
    left_max[0] = h[l];
    for (int i = 1; i < n; ++i) {
        left_max[i] = max(left_max[i-1], h[l + i]);
    }
    vector<int> right_max(n);
    right_max[n-1] = h[r];
    for (int i = n-2; i >= 0; --i) {
        right_max[i] = max(right_max[i+1], h[l + i]);
    }
    for (int i = 0; i < n; ++i) {
        sum += min(left_max[i], right_max[i]) - h[l + i];
    }
    return sum;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n;
    cin >> n;
    vector<int> h(n);
    for (int& hi : h) {
        cin >> hi;
    }
    vector<int> instructions(n-1);
    for (int& kj : instructions) {
        cin >> kj;
    }
    
    vector<Segment> segments;
    for (int i = 0; i < n; ++i) {
        segments.push_back({i, i});
    }
    
    for (int kj : instructions) {
        int idx = kj - 1; // Convert 1-based to 0-based index
        Segment s1 = segments[idx];
        Segment s2 = segments[idx + 1];
        int new_l = s1.l;
        int new_r = s2.r;
        int cap = calculate_capacity(h, new_l, new_r);
        cout << cap << '\n';
        segments.erase(segments.begin() + idx, segments.begin() + idx + 2);
        segments.insert(segments.begin() + idx, {new_l, new_r});
    }
    
    return 0;
}