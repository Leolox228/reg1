import sys
from collections import defaultdict

MOD = 10**9 + 7

def main():
    n, k = map(int, sys.stdin.readline().split())
    b = list(map(int, sys.stdin.readline().split()))
    
    # Precompute contributions for all possible masks (0 to 2^k - 1)
    mask_contributions = []
    for mask in range(0, 1 << k):
        contrib = []
        for m in range(k):
            top = k - m
            if top <= 0:
                contrib.append(0)
                continue
            bits = (mask >> (k - top)) & ((1 << top) - 1)
            count = bin(bits).count('1')
            contrib.append(count)
        mask_contributions.append(contrib)
    
    # Group masks by their c0 (contribution[0])
    mask_grouped = defaultdict(list)
    for mask, contrib in enumerate(mask_contributions):
        c0 = contrib[0]
        mask_grouped[c0].append(mask)
    
    # Initialize DP
    dp = [defaultdict(int) for _ in range(n + 1)]
    initial_state = tuple([0] * (min(k-1, n))) if n > 0 else tuple()
    dp[0][initial_state] = 1
    
    for i in range(n):
        current_dp = dp[i]
        next_dp = defaultdict(int)
        for state, count in current_dp.items():
            if len(state) == 0:
                required_c0 = b[i]
            else:
                required_c0 = b[i] - state[0]
            
            if required_c0 < 0 or required_c0 > k:
                continue
            
            masks = mask_grouped.get(required_c0, [])
            for mask in masks:
                contrib = mask_contributions[mask]
                new_state = []
                valid = True
                for m in range(1, k):
                    p = i + m
                    if p >= n:
                        break
                    if (m - 1) < len(state):
                        prev_sum = state[m - 1]
                    else:
                        prev_sum = 0
                    new_sum = prev_sum + contrib[m]
                    if new_sum > b[p]:
                        valid = False
                        break
                    new_state.append(new_sum)
                if valid:
                    new_state_tuple = tuple(new_state)
                    next_dp[new_state_tuple] = (next_dp[new_state_tuple] + count) % MOD
        dp[i + 1] = next_dp
    
    answer = dp[n].get(tuple(), 0) % MOD
    print(answer)

if __name__ == "__main__":
    main()